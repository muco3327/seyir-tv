package tv.newtv.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import tv.newtv.data.local.VodCatalogDao
import tv.newtv.data.local.VodCatalogEntity
import tv.newtv.data.models.MovieItem
import tv.newtv.data.models.SeriesItem
import tv.newtv.scraper.MovieScraper
import tv.newtv.scraper.SeriesScraper
import tv.newtv.scraper.VodProviderManager
import java.text.Normalizer
import java.util.Locale

class VodCatalogEngine(
    private val dao: VodCatalogDao,
    private val providers: VodProviderManager
) {
    private val providerConcurrency = Semaphore(2)

    suspend fun scanMovies(onProgress: suspend (String, Int) -> Unit = { _, _ -> }) = supervisorScope {
        providers.movieScrapers.map { scraper ->
            async(Dispatchers.IO) { providerConcurrency.withPermit { scanMovieProvider(scraper, onProgress) } }
        }.awaitAll()
    }

    suspend fun scanSeries(onProgress: suspend (String, Int) -> Unit = { _, _ -> }) = supervisorScope {
        providers.seriesScrapers.map { scraper ->
            async(Dispatchers.IO) { providerConcurrency.withPermit { scanSeriesProvider(scraper, onProgress) } }
        }.awaitAll()
    }

    suspend fun movies(): List<MovieItem> = withContext(Dispatchers.IO) {
        deduplicate(dao.getCatalog(true)).map {
            MovieItem(it.title, it.url, it.posterUrl, provider = it.provider, languages = decodeLanguages(it.languagesJson))
        }
    }

    suspend fun series(): List<SeriesItem> = withContext(Dispatchers.IO) {
        deduplicate(dao.getCatalog(false)).map {
            SeriesItem(it.title, it.url, it.posterUrl, provider = it.provider, languages = decodeLanguages(it.languagesJson))
        }
    }

    suspend fun movieCandidates(): List<MovieItem> = withContext(Dispatchers.IO) {
        dao.getCatalog(true).map {
            MovieItem(it.title, it.url, it.posterUrl, provider = it.provider, languages = decodeLanguages(it.languagesJson))
        }
    }

    suspend fun movieSources(title: String): List<MovieItem> = movieCandidates().filter {
        MovieSourceResolver.sameMovie(MovieItem(title, "", ""), it)
    }

    suspend fun seriesSources(title: String): List<SeriesItem> = withContext(Dispatchers.IO) {
        dao.getSourcesForTitle(false, normalizeTitle(title)).map {
            SeriesItem(it.title, it.url, it.posterUrl, provider = it.provider, languages = decodeLanguages(it.languagesJson))
        }
    }

    private suspend fun scanMovieProvider(scraper: MovieScraper, onProgress: suspend (String, Int) -> Unit) {
        val scanStartedAt = System.currentTimeMillis()
        val seenUrls = mutableSetOf<String>()
        var saved = 0
        var emptyOrRepeatedPages = 0
        var reachedEnd = false
        for (page in 1..MAX_SOURCE_PAGES) {
            val items = runCatching { scraper.getCategories(page).flatMap { it.items } }.getOrDefault(emptyList())
            val fresh = items.filter { it.url.isNotBlank() && seenUrls.add(it.url) }
            if (fresh.isEmpty()) {
                emptyOrRepeatedPages++
                if (emptyOrRepeatedPages >= END_CONFIRMATION_PAGES) {
                    reachedEnd = true
                    break
                }
                delay(PAGE_DELAY_MS)
                continue
            }
            emptyOrRepeatedPages = 0
            dao.upsert(fresh.map { it.toEntity(scraper.name, scanStartedAt + page) })
            saved += fresh.size
            onProgress(scraper.name, saved)
            delay(PAGE_DELAY_MS)
        }
        // Geçici ağ hatasında daha önce çalışan kayıtları silme.
        if (saved > 0 && reachedEnd) dao.deleteStale(scraper.name, true, scanStartedAt)
    }

    private suspend fun scanSeriesProvider(scraper: SeriesScraper, onProgress: suspend (String, Int) -> Unit) {
        val scanStartedAt = System.currentTimeMillis()
        val seenUrls = mutableSetOf<String>()
        var saved = 0
        var emptyOrRepeatedPages = 0
        var reachedEnd = false
        for (page in 1..MAX_SOURCE_PAGES) {
            val items = runCatching { scraper.getCategories(page).flatMap { it.items } }.getOrDefault(emptyList())
            val fresh = items.filter { it.url.isNotBlank() && seenUrls.add(it.url) }
            if (fresh.isEmpty()) {
                emptyOrRepeatedPages++
                if (emptyOrRepeatedPages >= END_CONFIRMATION_PAGES) {
                    reachedEnd = true
                    break
                }
                delay(PAGE_DELAY_MS)
                continue
            }
            emptyOrRepeatedPages = 0
            dao.upsert(fresh.map { it.toEntity(scraper.name, scanStartedAt + page) })
            saved += fresh.size
            onProgress(scraper.name, saved)
            delay(PAGE_DELAY_MS)
        }
        if (saved > 0 && reachedEnd) dao.deleteStale(scraper.name, false, scanStartedAt)
    }

    private fun MovieItem.toEntity(fallbackProvider: String, timestamp: Long): VodCatalogEntity {
        val sourceProvider = provider.ifBlank { fallbackProvider }
        return VodCatalogEntity(
        catalogKey = "M|$sourceProvider|$url",
        title = title.trim(), normalizedTitle = normalizeTitle(title), url = url,
        posterUrl = posterUrl, provider = sourceProvider, isMovie = true,
        languagesJson = JSONArray(languages).toString(), updatedAt = timestamp
        )
    }

    private fun SeriesItem.toEntity(fallbackProvider: String, timestamp: Long): VodCatalogEntity {
        val sourceProvider = provider.ifBlank { fallbackProvider }
        return VodCatalogEntity(
        catalogKey = "S|$sourceProvider|$url",
        title = title.trim(), normalizedTitle = normalizeTitle(title), url = url,
        posterUrl = posterUrl, provider = sourceProvider, isMovie = false,
        languagesJson = JSONArray(languages).toString(), updatedAt = timestamp
        )
    }

    private fun deduplicate(items: List<VodCatalogEntity>): List<VodCatalogEntity> = items
        .groupBy { it.normalizedTitle.ifBlank { it.url.lowercase(Locale.ROOT) } }
        .values
        .map { matches -> matches.maxWith(compareBy<VodCatalogEntity> { it.posterUrl.isNotBlank() }.thenBy { it.updatedAt }) }
        .sortedBy { it.normalizedTitle }

    private fun decodeLanguages(raw: String): List<String> = runCatching {
        val array = JSONArray(raw)
        List(array.length()) { array.optString(it) }.filter { it.isNotBlank() }
    }.getOrDefault(emptyList())

    companion object {
        const val PAGE_SIZE = 50
        // Diziwatch arşivi sayfa başına 10 kayıtla 300'den fazla sayfa sunuyor.
        // Tarama boş/tekrar eden ilk sayfada zaten otomatik durur.
        private const val MAX_SOURCE_PAGES = 900
        private const val END_CONFIRMATION_PAGES = 2
        private const val PAGE_DELAY_MS = 180L

        fun normalizeTitle(value: String): String {
            val decomposed = Normalizer.normalize(value.lowercase(Locale("tr", "TR")), Normalizer.Form.NFD)
            return decomposed.replace(Regex("\\p{M}+"), "")
                .replace(Regex("\\([^)]*\\)|\\[[^]]*]"), " ")
                .replace(Regex("\\b(izle|turkce|dublaj|altyazili|full|hd|film|dizi)\\b"), " ")
                .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
                .trim()
        }
    }
}
