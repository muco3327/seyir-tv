package tv.newtv.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import tv.newtv.data.local.ChannelEntity
import tv.newtv.data.local.ChannelStatus
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

object M3uParser {

    /**
     * Kanal isminde kaynakta ne yazıyorsa (örn: "bein sport 1 hd", "bein sport sd") onu korur.
     * Sadece başta gereksiz bulunan "TR:" veya "[TR]" gibi ülke etiketlerini temizler.
     */
    fun cleanChannelName(rawName: String): String {
        var clean = rawName.trim()
        clean = clean.replace(Regex("""^(?:(?:TR|TURK|TURKEY)\s*[:|\-]\s*|\[(?:TR|TURK)\]\s*|\|(?:TR|TURK)\|\s*)""", RegexOption.IGNORE_CASE), "")
        clean = clean.replace(Regex("""\s+"""), " ").trim()
        return if (clean.isNotEmpty()) clean else rawName.trim()
    }

    /**
     * StreamScope mantığıyla kanalları birleştirmek için standart normalize edilmiş anahtar üretir.
     * Çözünürlük etiketleri (HD, FHD, 4K, 1080p), FPS bilgileri ve ülke ön ekleri temizlenir.
     * Örn: "[TR] beIN Sports 1 FHD (50fps)" -> "bein sports 1"
     */
    fun getCanonicalKey(rawName: String): String {
        var text = cleanChannelName(rawName).lowercase()

        // Türkçe karakterleri normalize et
        text = text.replace('ı', 'i')
            .replace('ğ', 'g')
            .replace('ü', 'u')
            .replace('ş', 's')
            .replace('ö', 'o')
            .replace('ç', 'c')

        // Parantez içindeki kalite / yedek / fps bilgilerini temizle: (50fps), [fhd], (yedek)
        text = text.replace(Regex("""\([^\d\)]*(?:fps|fhd|hd|sd|uhd|4k|raw|yedek|backup|vip)[^\)]*\)""", RegexOption.IGNORE_CASE), " ")
        text = text.replace(Regex("""\[[^\d\]]*(?:fps|fhd|hd|sd|uhd|4k|raw|yedek|backup|vip)[^\]]*\]""", RegexOption.IGNORE_CASE), " ")

        // Kalite ve teknik terimleri temizle
        val junkWords = listOf(
            "1080p", "720p", "4k", "fhd", "uhd", "1080i", "576i", "50fps", "60fps", "100fps",
            "hevc", "h265", "h264", "h.265", "h.264", "raw", "vip", "yedek", "backup", "donmasiz",
            "hq", "hd", "sd"
        )
        for (w in junkWords) {
            text = text.replace(Regex("""\b${Regex.escape(w)}\b""", RegexOption.IGNORE_CASE), " ")
        }

        // Spor tekil/çoğul eşitleme (sport -> sports)
        text = text.replace(Regex("""\bspor\b"""), "sports")
        text = text.replace(Regex("""\bsport\b"""), "sports")

        // Özel karakterleri boşluğa dönüştür, sadece alfanümerik kalsın
        text = text.replace(Regex("""[^a-z0-9]"""), " ")
        text = text.replace(Regex("""\s+"""), " ").trim()

        return if (text.isNotEmpty()) text else rawName.trim().lowercase()
    }

    /**
     * Sadece "Spor Kanalları" ve "Ulusal Kanallar"ı kabul eder.
     * Belgesel, Sinema, Dizi, Çocuk, Müzik, Yabancı vb. kanallar null döner ve elenir.
     */
    fun determineCategory(name: String, groupTitle: String?): String? {
        val clean = cleanChannelName(name)
        val lowerName = clean.lowercase()
        val lowerGroup = (groupTitle ?: "").lowercase()

        // Yabancı ülke gruplarını (au, ca, de, es, fr, nl, pt, world vb.) doğrudan ele
        val foreignGroups = setOf("au", "ca", "de", "es", "fr", "nl", "pt", "world", "it", "uk", "us", "ru", "ar")
        if (lowerGroup in foreignGroups) {
            return null
        }

        // beIN sinema / dizi / yemek kanallarını spor dışında tut
        if (lowerName.contains("bein")) {
            val nonSportsBein = listOf("series", "movie", "sinema", "gurme", "box office", "izle", "connect")
            if (nonSportsBein.any { lowerName.contains(it) }) {
                return null
            }
        }

        // 1. SPOR KANALLARI (Tüm beIN Sport, S Sport, Tivibu, TRT Spor, A Spor, Exxen vb.)
        val isSport = lowerName.contains("bein") ||
                      lowerName.contains("spor") ||
                      lowerName.contains("sport") ||
                      lowerName.contains("ssport") ||
                      lowerName.contains("s sport") ||
                      lowerName.contains("eurosport") ||
                      lowerName.contains("tivibu") ||
                      lowerName.contains("exxen") ||
                      lowerName.contains("smart spor") ||
                      lowerName.contains("nba") ||
                      lowerName.contains("futbol") ||
                      lowerName.contains("dsmart spor") ||
                      lowerGroup.contains("spor") ||
                      lowerGroup.contains("sport") ||
                      lowerGroup.contains("bein")

        if (isSport) {
            // Yabancı beIN ve spor kanallarını filtrele
            val foreignSports = listOf("france", "arabic", "malaysia", "australia", "en espa", "usa-us", "qatar-qa")
            if (foreignSports.any { lowerName.contains(it) }) {
                return null
            }
            return "Spor Kanalları"
        }

        // 2. ULUSAL KANALLAR
        val ulusalKeywords = listOf(
            "trt 1", "trt1", "atv", "kanal d", "kanald", "show tv", "showtv", "star tv", "startv",
            "tv8", "tv 8", "tv8.5", "tv 8.5", "fox", "now tv", "now uhd", "now hd", "now hq", "now sd",
            "beyaz tv", "beyaztv", "kanal 7", "kanal7", "teve2", "teve 2", "tlc", "dmax", "a2 tv", "a2 hd", "a2",
            "360 tv", "360", "tv4", "trt belgesel", "trt haber", "trt avaz", "trt türk", "trt turk",
            "a haber", "ahaber", "habertürk", "haber türk", "haberturk", "ntv", "cnn türk", "cnnturk",
            "halk tv", "halktv", "tele1", "tele 1", "sözcü", "sozcu", "ekol tv", "flash tv", "flash haber",
            "ülke tv", "ulke tv", "tgrt haber", "tgrt", "24 tv", "tvnet", "bengü türk", "benguturk",
            "bloomberg ht", "bloomberg", "kral tv"
        )

        val isUlusal = ulusalKeywords.any { lowerName.contains(it) } || (
            (lowerGroup.contains("ulusal") || lowerGroup.contains("haber") || lowerGroup.contains("general") || lowerGroup.contains("national"))
            && !listOf("sinema", "film", "dizi", "belgesel", "çocuk", "cocuk", "müzik", "muzik").any { lowerGroup.contains(it) }
        )

        if (isUlusal) {
            return "Ulusal Kanallar"
        }

        // Geri kalan kanallar (Sinema, Dizi, Belgesel, Çocuk, Müzik, Yabancı vb.) Canlı TV'ye eklenmeyecek
        return null
    }

    /**
     * Büyük M3U dosyalarında OOM (Out of Memory) oluşmasını engellemek için
     * InputStream üzerinden satır satır okuma yapar ve yakaladığı her kanalı Flow olarak yayar (emit).
     */
    fun parse(inputStream: InputStream, sourceUrl: String): Flow<ChannelEntity> = flow {
        BufferedReader(InputStreamReader(inputStream)).use { reader ->
            var line: String?
            var currentName = ""
            var currentLogo: String? = null
            var currentGroup: String? = null

            // Regex desenleri
            val logoRegex = Regex("""tvg-logo="([^"]+)"""")
            val groupRegex = Regex("""group-title="([^"]+)"""")

            while (reader.readLine().also { line = it } != null) {
                val currentLine = line?.trim() ?: continue

                if (currentLine.startsWith("#EXTINF:")) {
                    // Logoyu çıkar
                    val logoMatch = logoRegex.find(currentLine)
                    currentLogo = logoMatch?.groupValues?.get(1)

                    // Kategoriyi çıkar
                    val groupMatch = groupRegex.find(currentLine)
                    currentGroup = groupMatch?.groupValues?.get(1)

                    // Kanal adını çıkar (virgülden sonraki kısmın tamamı)
                    val nameSplit = currentLine.split(",")
                    currentName = if (nameSplit.size > 1) {
                        nameSplit.subList(1, nameSplit.size).joinToString(",").trim()
                    } else {
                        val tvgNameMatch = Regex("""tvg-name="([^"]+)"""").find(currentLine)
                        tvgNameMatch?.groupValues?.get(1)?.trim() ?: "Bilinmeyen Kanal"
                    }
                } else if (!currentLine.startsWith("#") && currentLine.isNotEmpty()) {
                    // Yorum veya başlık değilse, ve boş değilse akış linkidir
                    val streamUrl = currentLine

                    if (currentName.isNotEmpty() && streamUrl.isNotEmpty()) {
                        val categorizedGroup = determineCategory(currentName, currentGroup)
                        if (categorizedGroup != null) {
                            val finalName = cleanChannelName(currentName)
                            val canonical = getCanonicalKey(finalName)
                            emit(
                                ChannelEntity(
                                    name = finalName,
                                    logoUrl = currentLogo,
                                    groupTitle = categorizedGroup,
                                    streamUrl = streamUrl,
                                    sourceListUrl = sourceUrl,
                                    canonicalKey = canonical,
                                    streamUrlsJson = org.json.JSONArray(listOf(streamUrl)).toString(),
                                    sourceCount = 1,
                                    isFavorite = false,
                                    status = ChannelStatus.UNKNOWN
                                )
                            )
                        }
                    }

                    // Bir sonraki kanal için değişkenleri sıfırla
                    currentName = ""
                    currentLogo = null
                    currentGroup = null
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}
