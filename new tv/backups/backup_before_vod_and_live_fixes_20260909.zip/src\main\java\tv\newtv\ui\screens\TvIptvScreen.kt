package tv.newtv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.CircularProgressIndicator
import androidx.tv.material3.Icon
import androidx.tv.material3.Text
import coil.compose.AsyncImage
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import tv.newtv.data.local.ChannelEntity
import tv.newtv.data.local.ChannelStatus
import tv.newtv.ui.viewmodel.ChannelFilterType
import tv.newtv.ui.viewmodel.TvMainViewModel

fun detectChannelQuality(name: String): Pair<String, Color> {
    val upper = name.uppercase()
    return when {
        upper.contains("4K") || upper.contains("UHD") || upper.contains("2160P") -> Pair("4K", Color(0xFFEF4444))
        upper.contains("FHD") || upper.contains("1080P") || upper.contains("FULL HD") -> Pair("FHD", Color(0xFFF59E0B))
        upper.contains("HD") || upper.contains("720P") -> Pair("HD", Color(0xFF10B981))
        else -> Pair("SD", Color(0xFF94A3B8))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TvIptvScreen(
    viewModel: TvMainViewModel,
    onChannelClick: (channel: ChannelEntity, sourceIndex: Int) -> Unit
) {
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val channels by viewModel.displayChannels.collectAsStateWithLifecycle()
    val selectedSource by viewModel.selectedSource.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val totalCount by viewModel.totalCount.collectAsStateWithLifecycle()
    val channelStatuses by viewModel.channelStatuses.collectAsStateWithLifecycle()
    val channelFilter by viewModel.channelFilter.collectAsStateWithLifecycle()
    val activeCount by viewModel.activeCount.collectAsStateWithLifecycle()
    val offlineCount by viewModel.offlineCount.collectAsStateWithLifecycle()
    val isVerifying by viewModel.isVerifying.collectAsStateWithLifecycle()
    val verificationProgress by viewModel.verificationProgress.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showGitHubDialog by remember { mutableStateOf(false) }
    var selectedChannelForSources by remember { mutableStateOf<ChannelEntity?>(null) }
    var showSearchDialog by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        // Sol Sütun: Modern Kategori & Araçlar Menüsü (230dp)
        Column(
            modifier = Modifier
                .width(230.dp)
                .fillMaxHeight()
                .padding(vertical = 12.dp, horizontal = 4.dp)
        ) {
            Text(
                text = "CANLI KANALLAR",
                color = Color(0xFF64748B),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // 1. SPOR KANALLARI
                val isSportsSelected = selectedSource == TvMainViewModel.VIRTUAL_SPORTS_SOURCE
                item {
                    TvSourceItem(
                        title = "🏆 Spor Kanalları",
                        isSelected = isSportsSelected,
                        onClick = {
                            viewModel.setSearchQuery("")
                            viewModel.selectSource(TvMainViewModel.VIRTUAL_SPORTS_SOURCE)
                        }
                    )
                }
                if (isSportsSelected) {
                    items(categories) { category ->
                        TvCategorySubItem(
                            title = category,
                            isSelected = selectedCategory == category,
                            onClick = {
                                viewModel.setSearchQuery("")
                                viewModel.selectCategory(category)
                            }
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(6.dp)) }

                // 2. ULUSAL KANALLAR
                val isNationalSelected = selectedSource == TvMainViewModel.VIRTUAL_NATIONAL_SOURCE
                item {
                    TvSourceItem(
                        title = "🇹🇷 Ulusal Kanallar",
                        isSelected = isNationalSelected,
                        onClick = {
                            viewModel.setSearchQuery("")
                            viewModel.selectSource(TvMainViewModel.VIRTUAL_NATIONAL_SOURCE)
                        }
                    )
                }
                if (isNationalSelected) {
                    items(categories) { category ->
                        TvCategorySubItem(
                            title = category,
                            isSelected = selectedCategory == category,
                            onClick = {
                                viewModel.setSearchQuery("")
                                viewModel.selectCategory(category)
                            }
                        )
                    }
                }

                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 4.dp)
                            .height(1.dp)
                            .background(Color(0xFF1E2430))
                    )
                }

                // ARAÇLAR VE ÖZELLİKLER BÖLÜMÜ
                item {
                    Text(
                        text = "ARAÇLAR & AYARLAR",
                        color = Color(0xFF64748B),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
                    )
                }

                // A. Kanal Ara
                item {
                    TvToolMenuItem(
                        title = if (searchQuery.isNotBlank()) "Arama: \"$searchQuery\"" else "🔍 Kanal Ara...",
                        color = Color(0xFF38BDF8),
                        onClick = { showSearchDialog = true }
                    )
                }

                // B. GitHub Canlı M3U Keşfi
                item {
                    TvToolMenuItem(
                        title = "🌐 GitHub M3U Keşfi",
                        color = Color(0xFFFBBF24),
                        onClick = { showGitHubDialog = true }
                    )
                }

                // C. Kanalları Doğrula
                item {
                    TvToolMenuItem(
                        title = if (isVerifying) "⚡ Doğrulanıyor..." else "⚡ Kanalları Test Et",
                        color = Color(0xFF10B981),
                        onClick = { viewModel.startVerification(force = true) }
                    )
                }

                // D. Oynatıcı & Performans Ayarları (Resimdeki Ayarlar)
                item {
                    TvToolMenuItem(
                        title = "⚙ Performans Ayarları",
                        color = Color(0xFF60A5FA),
                        onClick = { showSettingsDialog = true }
                    )
                }

                // E. Listeleri Yenile
                item {
                    TvToolMenuItem(
                        title = "🔄 Listeleri Yenile",
                        color = Color(0xFFFB923C),
                        onClick = { viewModel.refreshPlaylists() }
                    )
                }
            }
        }

        // Ayırıcı İnce Dikey Çizgi
        Box(
            modifier = Modifier
                .width(1.dp)
                .fillMaxHeight()
                .padding(vertical = 14.dp)
                .background(Color(0xFF1E222B))
        )

        // Sağ Alan: Başlık, Filtreler ve Kanal Izgarası
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 4.dp)
        ) {
            // Minimal Başlık, Filtre Çipleri ve Doğrulama Durumu
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp, start = 4.dp, end = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (searchQuery.isNotBlank()) "Arama Sonuçları" else (selectedCategory ?: "Tüm Kanallar"),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF222632), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF333A4C), RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "$totalCount Kanal",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (isVerifying) {
                        Spacer(modifier = Modifier.width(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                color = Color(0xFF38BDF8)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Test ediliyor: ${verificationProgress.first}/${verificationProgress.second}",
                                color = Color(0xFF38BDF8),
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // 3'lü Filtre Butonları (Tümü, Aktif, Kapalı)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TvFilterChip(
                        title = "Tümü",
                        count = totalCount,
                        isSelected = channelFilter == ChannelFilterType.ALL,
                        badgeColor = Color(0xFF64748B),
                        onClick = { viewModel.setChannelFilter(ChannelFilterType.ALL) }
                    )
                    TvFilterChip(
                        title = "Aktif",
                        count = activeCount,
                        isSelected = channelFilter == ChannelFilterType.ACTIVE,
                        badgeColor = Color(0xFF10B981),
                        onClick = { viewModel.setChannelFilter(ChannelFilterType.ACTIVE) }
                    )
                    TvFilterChip(
                        title = "Kapalı",
                        count = offlineCount,
                        isSelected = channelFilter == ChannelFilterType.OFFLINE,
                        badgeColor = Color(0xFFEF4444),
                        onClick = { viewModel.setChannelFilter(ChannelFilterType.OFFLINE) }
                    )
                }
            }

            if (channels.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isNotBlank()) "\"$searchQuery\" ile eşleşen kanal bulunamadı." else "Kanal listesi yükleniyor veya kanal bulunamadı...",
                        color = Color.Gray,
                        fontSize = 15.sp
                    )
                }
            } else {
                LazyVerticalGrid(
                    state = viewModel.channelGridState,
                    columns = GridCells.Fixed(6),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 28.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(
                        items = channels,
                        key = { it.id }
                    ) { channel ->
                        val status = channelStatuses[channel.id] ?: channel.status
                        val isTarget = channel.id == viewModel.lastFocusedChannelId
                        TvChannelCard(
                            channel = channel,
                            status = status,
                            isInitiallyFocused = isTarget,
                            onClick = {
                                viewModel.lastFocusedChannelId = channel.id
                                onChannelClick(channel, 0)
                            },
                            onLongClick = {
                                selectedChannelForSources = channel
                            }
                        )
                    }
                }
            }
        }
    }

    // Dialoglar
    if (showSettingsDialog) {
        TvPerformanceSettingsDialog(
            onDismiss = { showSettingsDialog = false }
        )
    }

    if (showGitHubDialog) {
        TvGitHubScannerDialog(
            onDismiss = { showGitHubDialog = false },
            onPlaylistsAdded = { urls ->
                viewModel.refreshPlaylists(urls)
            }
        )
    }

    selectedChannelForSources?.let { channel ->
        TvChannelSourceDialog(
            channel = channel,
            repository = viewModel.repository,
            onDismiss = { selectedChannelForSources = null },
            onSourceSelected = { sourceIndex ->
                onChannelClick(channel, sourceIndex)
            }
        )
    }

    if (showSearchDialog) {
        TvSearchInputDialog(
            initialQuery = searchQuery,
            onDismiss = { showSearchDialog = false },
            onSearchConfirmed = { query ->
                viewModel.setSearchQuery(query)
                showSearchDialog = false
            }
        )
    }
}

@Composable
fun TvSourceItem(title: String, isSelected: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val bg = when {
        isFocused -> Color.White
        isSelected -> Color(0xFF222634)
        else -> Color.Transparent
    }
    val textColor = when {
        isFocused -> Color.Black
        isSelected -> Color.White
        else -> Color(0xFFCBD5E1)
    }
    val borderColor = when {
        isFocused -> Color.White
        isSelected -> Color(0xFFE50914)
        else -> Color.Transparent
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .scale(if (isFocused) 1.04f else 1.0f)
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .border(
                width = if (isFocused) 2.dp else if (isSelected) 1.5.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(8.dp)
            )
            .focusable(interactionSource = interactionSource)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = title,
            color = textColor,
            fontWeight = if (isFocused || isSelected) FontWeight.Bold else FontWeight.SemiBold,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TvCategorySubItem(title: String, isSelected: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val bg = when {
        isFocused -> Color.White
        isSelected -> Color(0xFF1E232F)
        else -> Color.Transparent
    }
    val textColor = when {
        isFocused -> Color.Black
        isSelected -> Color(0xFFE50914)
        else -> Color(0xFF94A3B8)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, top = 2.dp, bottom = 2.dp, end = 4.dp)
            .scale(if (isFocused) 1.04f else 1.0f)
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(
                width = if (isFocused) 2.dp else if (isSelected) 1.dp else 0.dp,
                color = if (isFocused) Color.White else if (isSelected) Color(0xFF333D52) else Color.Transparent,
                shape = RoundedCornerShape(6.dp)
            )
            .focusable(interactionSource = interactionSource)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(
            text = title,
            color = textColor,
            fontWeight = if (isFocused || isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TvToolMenuItem(title: String, color: Color, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .scale(if (isFocused) 1.04f else 1.0f)
            .clip(RoundedCornerShape(8.dp))
            .background(if (isFocused) Color.White else Color(0xFF141A28))
            .border(
                width = if (isFocused) 2.dp else 1.dp,
                color = if (isFocused) Color.White else Color(0xFF202A40),
                shape = RoundedCornerShape(8.dp)
            )
            .focusable(interactionSource = interactionSource)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(
            text = title,
            color = if (isFocused) Color.Black else color,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TvChannelCard(
    channel: ChannelEntity,
    status: ChannelStatus,
    isInitiallyFocused: Boolean = false,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    val focusRequester = remember { FocusRequester() }
    val quality = remember(channel.name) { detectChannelQuality(channel.name) }

    LaunchedEffect(isInitiallyFocused) {
        if (isInitiallyFocused) {
            kotlinx.coroutines.delay(120)
            runCatching { focusRequester.requestFocus() }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .focusRequester(focusRequester)
            .scale(if (isFocused) 1.08f else 1.0f)
            .background(
                color = if (isFocused) Color(0xFF282E39) else Color(0xFF1C1F26),
                shape = RoundedCornerShape(12.dp)
            )
            .border(
                width = if (isFocused) 2.5.dp else 1.dp,
                color = if (isFocused) Color(0xFFE50914) else Color(0xFF2C303A),
                shape = RoundedCornerShape(12.dp)
            )
            .focusable(interactionSource = interactionSource)
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyDown && (event.key == Key.Menu || event.key == Key.DirectionCenter && event.isAltPressed)) {
                    onLongClick()
                    true
                } else false
            }
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Üst Satır: Kategori + Kalite Rozeti + Kaynak Rozeti + Durum Noktası
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Sol: Kategori + Kalite
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val isSport = channel.groupTitle?.contains("Spor", ignoreCase = true) == true
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSport) Color(0xFFE50914).copy(alpha = 0.25f) else Color(0xFF1976D2).copy(alpha = 0.25f),
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isSport) "SPOR" else "ULUSAL",
                            color = if (isSport) Color(0xFFFF6B6B) else Color(0xFF64B5F6),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Çözünürlük Rozeti (4K, FHD, HD, SD)
                    Box(
                        modifier = Modifier
                            .background(quality.second.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = quality.first,
                            color = quality.second,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Sağ: Çoklu Kaynak Sayısı ve Durum Noktası
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (channel.sourceCount > 1) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF2C2411), RoundedCornerShape(4.dp))
                                .border(0.8.dp, Color(0xFFFFB300), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "⚡ ${channel.sourceCount}",
                                color = Color(0xFFFFD54F),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Aktiflik Durum Noktası
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                color = when (status) {
                                    ChannelStatus.ACTIVE -> Color(0xFF00E676)
                                    ChannelStatus.OFFLINE -> Color(0xFFFF3D00)
                                    ChannelStatus.UNKNOWN -> Color(0xFF6E7681)
                                },
                                shape = RoundedCornerShape(50)
                            )
                            .border(width = 1.dp, color = Color(0x33FFFFFF), shape = RoundedCornerShape(50))
                    )
                }
            }

            // Orta Alan: Kanal Logosu
            Box(
                modifier = Modifier.size(46.dp),
                contentAlignment = Alignment.Center
            ) {
                if (!channel.logoUrl.isNullOrEmpty()) {
                    AsyncImage(
                        model = channel.logoUrl,
                        contentDescription = channel.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(
                                color = if (isFocused) Color(0xFFE50914) else Color(0xFF2A313D),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Alt Alan: Kanal İsmi
            Text(
                text = channel.name,
                color = if (isFocused) Color.White else Color(0xFFE0E0E0),
                fontSize = 12.sp,
                lineHeight = 14.sp,
                fontWeight = if (isFocused) FontWeight.Bold else FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 2.dp)
            )
        }
    }
}

@Composable
fun TvFilterChip(
    title: String,
    count: Int,
    isSelected: Boolean,
    badgeColor: Color,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    Box(
        modifier = Modifier
            .scale(if (isFocused) 1.06f else 1.0f)
            .clip(RoundedCornerShape(16.dp))
            .background(
                color = when {
                    isFocused -> Color.White
                    isSelected -> Color(0xFF2A313D)
                    else -> Color(0xFF191C24)
                }
            )
            .border(
                width = if (isFocused) 2.dp else if (isSelected) 1.5.dp else 1.dp,
                color = when {
                    isFocused -> Color.White
                    isSelected -> badgeColor
                    else -> Color(0xFF2D323E)
                },
                shape = RoundedCornerShape(16.dp)
            )
            .focusable(interactionSource = interactionSource)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .background(
                        color = if (isFocused) Color.Black else badgeColor,
                        shape = RoundedCornerShape(50)
                    )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = if (isFocused) Color.Black else if (isSelected) Color.White else Color(0xFFBBBBBB),
                fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Medium,
                fontSize = 12.sp
            )
            if (count >= 0) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "($count)",
                    color = if (isFocused) Color.Black else Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun TvSearchInputDialog(
    initialQuery: String,
    onDismiss: () -> Unit,
    onSearchConfirmed: (String) -> Unit
) {
    var query by remember { mutableStateOf(initialQuery) }

    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .width(460.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF0F172A))
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "Kanal Arama",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                val sampleKeywords = listOf("TRT", "beIN", "Spor", "ATV", "Kanal D", "Show", "Star", "TV8", "S Sport", "Haber")
                Text(
                    text = "Hızlı Arama Önerileri:",
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Öneri butonları
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sampleKeywords.take(5).forEach { kw ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E293B))
                                .clickable { onSearchConfirmed(kw) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = kw, color = Color(0xFF38BDF8), fontSize = 12.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sampleKeywords.drop(5).forEach { kw ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E293B))
                                .clickable { onSearchConfirmed(kw) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = kw, color = Color(0xFF38BDF8), fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (query.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFEF4444))
                                .clickable { onSearchConfirmed("") }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(text = "Aramayı Temizle", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF334155))
                            .clickable { onDismiss() }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(text = "Kapat", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
