package tv.newtv.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Icon
import androidx.tv.material3.Text
import tv.newtv.data.local.IptvPerformanceSettings
import tv.newtv.data.local.IptvSettingsManager

@Composable
fun TvPerformanceSettingsDialog(
    onDismiss: () -> Unit,
    onSaved: (IptvPerformanceSettings) -> Unit = {}
) {
    val context = LocalContext.current
    val currentSettings = remember { IptvSettingsManager.getSettings(context) }

    var networkCaching by remember { mutableIntStateOf(currentSettings.networkCachingMs) }
    var liveCaching by remember { mutableIntStateOf(currentSettings.liveCachingMs) }
    var targetBuffer by remember { mutableIntStateOf(currentSettings.targetBufferSec) }

    var maxRetries by remember { mutableIntStateOf(currentSettings.maxRetries) }
    var concurrentTest by remember { mutableIntStateOf(currentSettings.concurrentTestCount) }
    var timeoutSec by remember { mutableIntStateOf(currentSettings.timeoutSec) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xCC000000)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .width(880.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0D1424))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                    .padding(28.dp)
            ) {
                // Üst Başlık
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFF00B0FF),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Oynatıcı ve Performans Ayarları",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Kapatma butonu
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E293B))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Kapat",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // 2 Sütunlu Ayar Kartları
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Sol Kart: Ön Bellekleme & Donma Önleme
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF131C31))
                            .border(1.dp, Color(0xFF22304E), RoundedCornerShape(12.dp))
                            .padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "⚡", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Ön Bellekleme & Donma Önleme",
                                color = Color(0xFF38BDF8),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        TvSettingInputItem(
                            label = "Ağ Önbellekleme / Network Caching (ms)",
                            value = networkCaching,
                            helpText = "Yayın açılış ve veri alma tampon süresi (Önerilen: 3000ms)",
                            onValueChange = { networkCaching = it },
                            step = 500,
                            min = 1000,
                            max = 10000
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        TvSettingInputItem(
                            label = "Canlı Yayın Önbellekleme / Live Caching (ms)",
                            value = liveCaching,
                            helpText = "Canlı HLS akışları için ara tampon (Önerilen: 3000ms)",
                            onValueChange = { liveCaching = it },
                            step = 500,
                            min = 1000,
                            max = 10000
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        TvSettingInputItem(
                            label = "Hedef Buffer Süresi (Saniye)",
                            value = targetBuffer,
                            helpText = "Ön oynatıcının hedeflediği akıcı buffer süresi",
                            onValueChange = { targetBuffer = it },
                            step = 5,
                            min = 15,
                            max = 120
                        )
                    }

                    // Sağ Kart: Kesinti Kurtarma & Tarama
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF131C31))
                            .border(1.dp, Color(0xFF22304E), RoundedCornerShape(12.dp))
                            .padding(18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🛡️", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Kesinti Kurtarma & Tarama",
                                color = Color(0xFF38BDF8),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        TvSettingInputItem(
                            label = "Maksimum Yeniden Deneme (Retry Count)",
                            value = maxRetries,
                            helpText = "Yayın koptuğunda otomatik yedek kaynağa geçiş ve tekrar sayısı",
                            onValueChange = { maxRetries = it },
                            step = 1,
                            min = 1,
                            max = 10
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        TvSettingInputItem(
                            label = "Eşzamanlı Kanal Test Sayısı",
                            value = concurrentTest,
                            helpText = "Arka planda kanal durumu taranırken açılacak bağlantı sayısı",
                            onValueChange = { concurrentTest = it },
                            step = 5,
                            min = 5,
                            max = 30
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        TvSettingInputItem(
                            label = "Bağlantı Zaman Aşımı / Timeout (Saniye)",
                            value = timeoutSec,
                            helpText = "Kanal yanıt vermediğinde vazgeçme süresi",
                            onValueChange = { timeoutSec = it },
                            step = 1,
                            min = 2,
                            max = 20
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Alt Buton: Ayarları Kaydet ve Uygula
                val saveInteractionSource = remember { MutableInteractionSource() }
                val isSaveFocused by saveInteractionSource.collectIsFocusedAsState()

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.35f)
                        .scale(if (isSaveFocused) 1.05f else 1.0f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSaveFocused) Color(0xFF0288D1) else Color(0xFF0091EA))
                        .border(
                            width = if (isSaveFocused) 2.dp else 0.dp,
                            color = Color.White,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .focusable(interactionSource = saveInteractionSource)
                        .clickable {
                            val newSettings = IptvPerformanceSettings(
                                networkCachingMs = networkCaching,
                                liveCachingMs = liveCaching,
                                targetBufferSec = targetBuffer,
                                maxRetries = maxRetries,
                                concurrentTestCount = concurrentTest,
                                timeoutSec = timeoutSec
                            )
                            IptvSettingsManager.saveSettings(context, newSettings)
                            onSaved(newSettings)
                            onDismiss()
                        }
                        .padding(vertical = 12.dp, horizontal = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ayarları Kaydet ve Uygula",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TvSettingInputItem(
    label: String,
    value: Int,
    helpText: String,
    onValueChange: (Int) -> Unit,
    step: Int,
    min: Int,
    max: Int
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            color = Color(0xFFCBD5E1),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(6.dp))

        // TV kumandasıyla kolayca azaltıp artırılabilen şık input kutusu
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF0A101D))
                .border(
                    width = if (isFocused) 2.dp else 1.dp,
                    color = if (isFocused) Color(0xFF00B0FF) else Color(0xFF1E2D4A),
                    shape = RoundedCornerShape(6.dp)
                )
                .focusable(interactionSource = interactionSource)
                .onKeyEvent { event ->
                    if (event.type == KeyEventType.KeyDown) {
                        when (event.key) {
                            Key.DirectionLeft -> {
                                val next = (value - step).coerceIn(min, max)
                                onValueChange(next)
                                true
                            }
                            Key.DirectionRight -> {
                                val next = (value + step).coerceIn(min, max)
                                onValueChange(next)
                                true
                            }
                            else -> false
                        }
                    } else false
                }
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$value",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                if (isFocused) {
                    Text(
                        text = "◄ Sol / Sağ ►",
                        color = Color(0xFF00B0FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = helpText,
            color = Color(0xFF64748B),
            fontSize = 11.sp,
            lineHeight = 14.sp
        )
    }
}
