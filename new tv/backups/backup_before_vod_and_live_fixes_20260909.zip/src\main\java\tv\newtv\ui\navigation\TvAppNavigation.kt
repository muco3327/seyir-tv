package tv.newtv.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.key.onKeyEvent
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.tv.material3.Icon
import androidx.tv.material3.Text
import tv.newtv.ui.screens.TvIptvScreen
import tv.newtv.ui.screens.TvVodScreen
import tv.newtv.ui.screens.TvPlayerScreen
import tv.newtv.ui.screens.TvDetailScreen
import tv.newtv.ui.screens.TvMovieDetailScreen
import tv.newtv.ui.screens.TvWatchHistoryScreen
import tv.newtv.ui.viewmodel.TvMainViewModel
import tv.newtv.ui.viewmodel.TvPlayerViewModel
import tv.newtv.ui.viewmodel.TvVodViewModel

enum class NavRoute { IPTV, HISTORY, MOVIES, SERIES, DETAIL, MOVIE_DETAIL, PLAYER }

@Composable
fun TvAppNavigation() {
    var currentRoute by remember { mutableStateOf(NavRoute.IPTV) }
    var playerReturnRoute by remember { mutableStateOf(NavRoute.IPTV) }
    var detailReturnRoute by remember { mutableStateOf(NavRoute.MOVIES) }
    
    val mainViewModel: TvMainViewModel = viewModel()
    val playerViewModel: TvPlayerViewModel = viewModel()
    val vodViewModel: TvVodViewModel = viewModel()
    val playableRequest by vodViewModel.playableRequest.collectAsStateWithLifecycle()
    val movieDetail by vodViewModel.movieDetail.collectAsStateWithLifecycle()
    val seriesDetail by vodViewModel.seriesDetail.collectAsStateWithLifecycle()
    val vodBusy by vodViewModel.isLoading.collectAsStateWithLifecycle()
    val vodError by vodViewModel.error.collectAsStateWithLifecycle()
    val favoriteUrls by vodViewModel.favoriteUrls.collectAsStateWithLifecycle()
    val favorites by vodViewModel.favorites.collectAsStateWithLifecycle()

    LaunchedEffect(playableRequest) {
        playableRequest?.let { req ->
            vodViewModel.consumePlayableRequest()
            if (req.iframes.isNotEmpty()) {
                playerViewModel.loadStreamFromIframe(
                    iframeUrls = req.iframes,
                    title = req.title,
                    isMovie = req.isMovie,
                    posterUrl = req.posterUrl,
                    dubbingIframes = req.dubbingIframes,
                    subtitleIframes = req.subtitleIframes,
                    selectedLanguage = req.selectedLanguage,
                    resolvedSource = req.resolvedSource
                )
                playerReturnRoute = if (req.isMovie) NavRoute.MOVIE_DETAIL else NavRoute.DETAIL
                currentRoute = NavRoute.PLAYER
            }
        }
    }

    // Otomatik Detay Yönlendirici (Film sekmesinden Dizi açılırsa NavRoute.DETAIL'e, Film açılırsa NavRoute.MOVIE_DETAIL'e geç)
    LaunchedEffect(movieDetail) {
        if (movieDetail != null && currentRoute == NavRoute.MOVIES) {
            currentRoute = NavRoute.MOVIE_DETAIL
        }
    }

    LaunchedEffect(seriesDetail) {
        if (seriesDetail != null && (currentRoute == NavRoute.MOVIES || currentRoute == NavRoute.SERIES)) {
            currentRoute = NavRoute.DETAIL
        }
    }

    // VOD ekranlarındayken hata varsa geri tuşu hatayı temizlesin, uygulamayı kapatmasın
    androidx.activity.compose.BackHandler(enabled = (currentRoute == NavRoute.MOVIES || currentRoute == NavRoute.SERIES) && vodError != null) {
        vodViewModel.clearError()
    }

    // Film detay sayfasındayken geri tuşu filmler listesine döndürsün
    androidx.activity.compose.BackHandler(enabled = currentRoute == NavRoute.MOVIE_DETAIL) {
        vodViewModel.clearMovieDetail()
        currentRoute = NavRoute.MOVIES
    }

    // Dizi detay sayfasındayken geri tuşu geldiği listeye (MOVIES veya SERIES) döndürsün
    androidx.activity.compose.BackHandler(enabled = currentRoute == NavRoute.DETAIL) {
        vodViewModel.clearSeriesDetail()
        currentRoute = detailReturnRoute
    }

    // Oynatıcı ekranındayken tam ekran göster, geri tuşunda geldiği rotaya dön
    if (currentRoute == NavRoute.PLAYER) {
        TvPlayerScreen(
            viewModel = playerViewModel,
            onBack = {
                currentRoute = when (playerReturnRoute) {
                    NavRoute.MOVIE_DETAIL -> if (movieDetail != null) NavRoute.MOVIE_DETAIL else NavRoute.MOVIES
                    NavRoute.DETAIL -> if (seriesDetail != null) NavRoute.DETAIL else NavRoute.SERIES
                    NavRoute.IPTV -> NavRoute.IPTV
                    NavRoute.HISTORY -> NavRoute.HISTORY
                    else -> NavRoute.MOVIES
                }
            }
        )
        return
    }

    // Sabit genişlikli Minimal Ray + Sağ İçerik Alanı (Sıfır genişlik animasyonu, tam 60 FPS TV performansı)
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0D10))
    ) {
        TvMinimalNavRail(
            currentRoute = currentRoute,
            onRouteSelected = { route ->
                if (currentRoute != route) {
                    currentRoute = route
                }
            }
        )

        // Sağ Taraf: Ana İçerik Alanı (Sabit genişlik, ölçüm kasması sıfır)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(Color(0xFF13151A))
        ) {
            when (currentRoute) {
                NavRoute.IPTV -> TvIptvScreen(
                    viewModel = mainViewModel,
                    onChannelClick = { channel, sourceIndex ->
                        playerReturnRoute = NavRoute.IPTV
                        playerViewModel.playChannelWithSource(channel, sourceIndex, allChannels = mainViewModel.displayChannels.value)
                        currentRoute = NavRoute.PLAYER
                    }
                )
                NavRoute.HISTORY -> TvWatchHistoryScreen(
                    playerViewModel = playerViewModel,
                    favorites = favorites,
                    onResume = { history ->
                        playerReturnRoute = NavRoute.HISTORY
                        playerViewModel.resume(history)
                        currentRoute = NavRoute.PLAYER
                    },
                    onFavoriteClick = { favorite ->
                        if (favorite.isMovie) vodViewModel.openMovie(tv.newtv.data.models.MovieItem(favorite.title, favorite.url, favorite.posterUrl))
                        else vodViewModel.openSeries(tv.newtv.data.models.SeriesItem(favorite.title, favorite.url, favorite.posterUrl))
                        currentRoute = if (favorite.isMovie) NavRoute.MOVIE_DETAIL else NavRoute.DETAIL
                    }
                )
                NavRoute.MOVIES -> TvVodScreen(
                    title = "Filmler",
                    movies = true,
                    viewModel = vodViewModel,
                    onMovieClick = {
                        detailReturnRoute = NavRoute.MOVIES
                        vodViewModel.openMovie(it)
                    },
                    onSeriesClick = {}
                )
                NavRoute.SERIES -> TvVodScreen(
                    title = "Diziler",
                    movies = false,
                    viewModel = vodViewModel,
                    onMovieClick = {},
                    onSeriesClick = {
                        detailReturnRoute = NavRoute.SERIES
                        vodViewModel.openSeries(it)
                    }
                )
                NavRoute.MOVIE_DETAIL -> {
                    movieDetail?.let { detail ->
                        TvMovieDetailScreen(
                            movieDetail = detail,
                            onPlayClick = { preferDubbing -> vodViewModel.playMovie(detail, preferDubbing) },
                            isFavorite = detail.sourceUrl in favoriteUrls,
                            onToggleFavorite = { vodViewModel.toggleFavorite(detail.sourceUrl, detail.title, detail.posterUrl, true) }
                        )
                    }
                }
                NavRoute.DETAIL -> seriesDetail?.let { detail ->
                    TvDetailScreen(
                        seriesDetail = detail,
                        onEpisodeClick = { episode, preferDubbing -> vodViewModel.openEpisode(episode.url, episode.name, preferDubbing) },
                        isFavorite = detail.sourceUrl in favoriteUrls,
                        onToggleFavorite = { vodViewModel.toggleFavorite(detail.sourceUrl, detail.title, detail.posterUrl, false) }
                    )
                }
                else -> {}
            }
            if (currentRoute == NavRoute.MOVIE_DETAIL && (vodBusy || vodError != null)) {
                Box(Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                    .background(Color.Black.copy(alpha = 0.9f)).padding(24.dp)) {
                    Text(if (vodBusy) "Film için açılabilir kaynak aranıyor…" else vodError.orEmpty(),
                        color = if (vodBusy) Color.White else Color(0xFFFF6060))
                }
            }
        }
    }
}

@Composable
fun TvMinimalNavRail(
    currentRoute: NavRoute,
    onRouteSelected: (NavRoute) -> Unit
) {
    Column(
        modifier = Modifier
            .width(76.dp)
            .fillMaxHeight()
            .background(Color(0xFF090A0D))
            .border(
                width = 1.dp,
                color = Color(0xFF1B1D24),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(vertical = 16.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Canlı TV
        TvRailItem(
            title = "Canlı TV",
            icon = Icons.Filled.Tv,
            isSelected = currentRoute == NavRoute.IPTV,
            onClick = { onRouteSelected(NavRoute.IPTV) }
        )

        Spacer(modifier = Modifier.height(14.dp))

        TvRailItem(
            title = "Devam Et",
            icon = Icons.Filled.History,
            isSelected = currentRoute == NavRoute.HISTORY,
            onClick = { onRouteSelected(NavRoute.HISTORY) }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 2. Filmcehennemi
        TvRailItem(
            title = "Film",
            icon = Icons.Filled.Movie,
            isSelected = currentRoute == NavRoute.MOVIES || currentRoute == NavRoute.MOVIE_DETAIL,
            onClick = { onRouteSelected(NavRoute.MOVIES) }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 3. Dizilla
        TvRailItem(
            title = "Dizi",
            icon = Icons.Filled.VideoLibrary,
            isSelected = currentRoute == NavRoute.SERIES || currentRoute == NavRoute.DETAIL,
            onClick = { onRouteSelected(NavRoute.SERIES) }
        )
    }
}

@Composable
fun TvRailItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val bg = when {
        isFocused -> Color.White
        isSelected -> Color(0xFFE50914)
        else -> Color(0xFF16181E)
    }

    val contentColor = when {
        isFocused -> Color.Black
        isSelected -> Color.White
        else -> Color(0xFF8E929D)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .scale(if (isFocused) 1.08f else 1.0f)
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(
                width = if (isFocused) 2.dp else 1.dp,
                color = if (isFocused) Color.White else if (isSelected) Color(0xFFFF5252) else Color(0xFF222530),
                shape = RoundedCornerShape(12.dp)
            )
            .focusable(interactionSource = interactionSource)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = contentColor,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            color = contentColor,
            fontSize = 11.sp,
            fontWeight = if (isFocused || isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
