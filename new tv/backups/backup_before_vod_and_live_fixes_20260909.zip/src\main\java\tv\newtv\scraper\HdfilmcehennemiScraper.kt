package tv.newtv.scraper

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import tv.newtv.data.models.Episode
import tv.newtv.data.models.EpisodeSources
import tv.newtv.data.models.MovieDetail
import tv.newtv.data.models.MovieItem
import tv.newtv.data.models.Season
import tv.newtv.data.models.VodCategory
import tv.newtv.utils.PosterUrlUtils

class HdfilmcehennemiScraper(private val client: OkHttpClient) : MovieScraper {
    override val name = "HDFilmcehennemi"
    private val baseUrl = "https://www.hdfilmcehennemi.now"
    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun fetchDocument(url: String): Document {
        val formattedUrl = if (url.startsWith("http")) url else if (url.startsWith("/")) "$baseUrl$url" else "$baseUrl/$url"
        val request = Request.Builder()
            .url(formattedUrl)
            .header("User-Agent", userAgent)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7")
            .build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) throw Exception("Failed to fetch: ${response.code}")
        val html = response.body?.string().orEmpty()
        return Jsoup.parse(html, formattedUrl)
    }

    /**
     * HDFilmcehennemi kartlarından (article veya poster) filmleri ayrıştırır.
     * data-src önceliklidir (1x1 şeffaf gif yerine gerçek webp afişi alır).
     */
    fun parseMoviesFromDoc(doc: Document): List<MovieItem> {
        val list = mutableListOf<MovieItem>()
        val seen = mutableSetOf<String>()

        doc.select("article, .item, .poster").forEach { itemEl ->
            val aTag = if (itemEl.tagName().equals("a", ignoreCase = true)) {
                itemEl
            } else {
                itemEl.selectFirst("a[href*='/film/']") ?: itemEl.selectFirst("a")
            } ?: return@forEach

            val href = aTag.attr("href")
            if (!href.contains("/film/", ignoreCase = true) || href.contains("/tur/", ignoreCase = true) || href.contains("/yil/", ignoreCase = true)) {
                return@forEach
            }

            val imgTag = itemEl.selectFirst("img") ?: return@forEach
            val titleEl = itemEl.selectFirst(".flbaslik, h2, h3, .data")
            val rawTitle = titleEl?.text()?.ifEmpty { imgTag.attr("alt") }?.ifEmpty { aTag.attr("title") } ?: ""
            val title = rawTitle.replace(" izle", "", ignoreCase = true).replace(" Poster", "", ignoreCase = true).trim()

            val poster = PosterUrlUtils.extractImgUrl(imgTag, baseUrl)
            val fullUrl = if (href.startsWith("http")) href else if (href.startsWith("/")) "$baseUrl$href" else "$baseUrl/$href"

            if (title.isNotEmpty() && !title.equals("film", ignoreCase = true) && poster.isNotBlank() && seen.add(fullUrl)) {
                list.add(MovieItem(title = title, url = fullUrl, posterUrl = poster, provider = name))
            }
        }

        // Fallback: Doğrudan film linklerini tara
        if (list.isEmpty()) {
            doc.select("a[href*='/film/']").forEach { aTag ->
                val href = aTag.attr("href")
                if (href.contains("/tur/", ignoreCase = true) || href.contains("/yil/", ignoreCase = true)) return@forEach

                val imgTag = aTag.selectFirst("img") ?: return@forEach
                val rawTitle = aTag.selectFirst(".flbaslik, h2, h3")?.text()
                    ?: imgTag.attr("alt").ifEmpty { aTag.attr("title") }
                val title = rawTitle.replace(" izle", "", ignoreCase = true).replace(" Poster", "", ignoreCase = true).trim()
                val poster = PosterUrlUtils.extractImgUrl(imgTag, baseUrl)
                val fullUrl = if (href.startsWith("http")) href else if (href.startsWith("/")) "$baseUrl$href" else "$baseUrl/$href"

                if (title.isNotEmpty() && !title.equals("film", ignoreCase = true) && poster.isNotBlank() && seen.add(fullUrl)) {
                    list.add(MovieItem(title = title, url = fullUrl, posterUrl = poster, provider = name))
                }
            }
        }
        return list
    }

    override suspend fun getRecent(page: Int): List<MovieItem> = withContext(Dispatchers.IO) {
        try {
            if (page <= 1) {
                val doc = fetchDocument("$baseUrl/film-izle-1/")
                parseMoviesFromDoc(doc)
            } else {
                // WordPress AJAX sayfalama
                val body = FormBody.Builder()
                    .add("action", "load_page_content")
                    .add("page", page.toString())
                    .add("content_type", "tr-altyazi-film")
                    .add("term_id", "6")
                    .build()
                val request = Request.Builder()
                    .url("$baseUrl/wp-admin/admin-ajax.php")
                    .header("User-Agent", userAgent)
                    .header("Referer", "$baseUrl/film-izle-1/")
                    .post(body)
                    .build()
                client.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext emptyList()
                    val html = resp.body?.string().orEmpty()
                    val doc = Jsoup.parse(html, baseUrl)
                    parseMoviesFromDoc(doc)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getRecent failed", e)
            emptyList()
        }
    }

    override suspend fun getCategories(page: Int): List<VodCategory<MovieItem>> = withContext(Dispatchers.IO) {
        val movies = getRecent(page)
        if (movies.isNotEmpty()) {
            listOf(VodCategory("Tüm Filmler", movies))
        } else {
            emptyList()
        }
    }

    /**
     * Kategoriye göre film listeleme
     */
    suspend fun getMoviesByGenre(genreSlug: String, page: Int = 1): List<MovieItem> = withContext(Dispatchers.IO) {
        try {
            if (genreSlug.isBlank() || genreSlug.equals("tum", ignoreCase = true)) {
                return@withContext getRecent(page)
            }
            val url = if (genreSlug.startsWith("http")) {
                genreSlug
            } else if (genreSlug.contains("yerli") || genreSlug.contains("turkce-dublaj")) {
                "$baseUrl/$genreSlug/"
            } else {
                "$baseUrl/tur/$genreSlug/"
            }

            if (page <= 1) {
                val doc = fetchDocument(url)
                parseMoviesFromDoc(doc)
            } else {
                // AJAX ile kategori sayfalaması
                val firstDoc = fetchDocument(url)
                val html = firstDoc.html()
                val dataType = Regex("""data-type=['"]([^'"]+)['"]""").find(html)?.groupValues?.get(1) ?: "ps"
                val termId = Regex("""data-term-id=['"]([^'"]+)['"]""").find(html)?.groupValues?.get(1) ?: "3"

                val body = FormBody.Builder()
                    .add("action", "load_page_content")
                    .add("page", page.toString())
                    .add("content_type", dataType)
                    .add("term_id", termId)
                    .build()
                val request = Request.Builder()
                    .url("$baseUrl/wp-admin/admin-ajax.php")
                    .header("User-Agent", userAgent)
                    .header("Referer", url)
                    .post(body)
                    .build()
                client.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) return@withContext emptyList()
                    val ajaxHtml = resp.body?.string().orEmpty()
                    val doc = Jsoup.parse(ajaxHtml, baseUrl)
                    parseMoviesFromDoc(doc)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "getMoviesByGenre failed for $genreSlug", e)
            emptyList()
        }
    }

    /**
     * Yıla göre film listeleme
     */
    suspend fun getMoviesByYear(year: String, page: Int = 1): List<MovieItem> = withContext(Dispatchers.IO) {
        try {
            if (year.isBlank() || year.equals("tum", ignoreCase = true)) {
                return@withContext getRecent(page)
            }
            val url = "$baseUrl/yil/$year/"
            val doc = fetchDocument(url)
            parseMoviesFromDoc(doc)
        } catch (e: Exception) {
            Log.e(TAG, "getMoviesByYear failed for $year", e)
            emptyList()
        }
    }

    override suspend fun search(query: String, page: Int): List<MovieItem> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext emptyList()
        try {
            val encoded = java.net.URLEncoder.encode(trimmed, "UTF-8")
            val searchUrl = "$baseUrl/?s=$encoded"
            val doc = fetchDocument(searchUrl)
            parseMoviesFromDoc(doc)
        } catch (e: Exception) {
            Log.e(TAG, "search failed for $trimmed", e)
            emptyList()
        }
    }

    override suspend fun getMovieDetail(movieUrl: String): MovieDetail = withContext(Dispatchers.IO) {
        val doc = fetchDocument(movieUrl)
        val html = doc.html()

        val rawTitle = doc.selectFirst("h1")?.text()?.ifEmpty { doc.selectFirst(".flbaslik")?.text() } ?: ""
        val title = rawTitle.replace(" izle", "", ignoreCase = true).trim()

        val description = doc.selectFirst("meta[name=description]")?.attr("content")
            ?: doc.selectFirst(".summary, .description, p.desc")?.text()
            ?: ""

        val posterEl = doc.selectFirst(".poster img, img[data-src*='uploads'], .poster")
        var poster = if (posterEl != null) PosterUrlUtils.extractImgUrl(posterEl, baseUrl) else ""
        if (poster.isBlank()) {
            poster = doc.selectFirst("meta[property='og:image']")?.attr("content")?.trim().orEmpty()
        }

        val iframes = mutableListOf<String>()
        val dubbingIframes = mutableListOf<String>()
        val subtitleIframes = mutableListOf<String>()
        var isSeries = false
        val seasonsMap = sortedMapOf<Int, MutableList<Episode>>()

        // 1. WordPress AJAX video URL sorgusu
        try {
            val ajaxNonce = Regex("""videoAjax\s*=\s*\{[^}]*nonce\s*:\s*['"]([a-f0-9]+)['"]""").find(html)?.groupValues?.get(1)
                ?: Regex("""['"]nonce['"]\s*:\s*['"]([a-f0-9]+)['"]""").find(html)?.groupValues?.get(1)
            val postId = Regex("""data-post-id=['"](\d+)['"]""").find(html)?.groupValues?.get(1)

            val playerNames = Regex("""data-player-name=['"]([^'"]+)['"]""")
                .findAll(html)
                .map { it.groupValues[1].trim() }
                .filter { it.isNotEmpty() && !it.contains("$") && !it.contains("+") }
                .distinct()
                .toList()
                .ifEmpty { listOf("SetPlay") }

            if (!ajaxNonce.isNullOrBlank() && !postId.isNullOrBlank()) {
                for (playerName in playerNames) {
                    val formBody = FormBody.Builder()
                        .add("action", "get_video_url")
                        .add("nonce", ajaxNonce)
                        .add("post_id", postId)
                        .add("player_name", playerName)
                        .add("part_key", "")
                        .build()

                    val request = Request.Builder()
                        .url("$baseUrl/wp-admin/admin-ajax.php")
                        .header("User-Agent", userAgent)
                        .header("Referer", movieUrl)
                        .header("X-Requested-With", "XMLHttpRequest")
                        .post(formBody)
                        .build()

                    client.newCall(request).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val body = resp.body?.string().orEmpty()
                            val json = try { JSONObject(body) } catch (_: Exception) { null }
                            val pUrl = json?.optJSONObject("data")?.optString("url")
                                ?: json?.optString("url")
                                ?: Regex("""https?://[^\s"'<>]+""").find(body)?.value

                            if (!pUrl.isNullOrBlank() && !iframes.contains(pUrl)) {
                                iframes.add(pUrl)
                                dubbingIframes.add(pUrl)
                                subtitleIframes.add(pUrl)
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to resolve ajax video url", e)
        }

        // 2. DOM iframe'lerini de kontrol et (fallback)
        doc.select("iframe").forEach { iframe ->
            val src = iframe.attr("src").ifEmpty { iframe.attr("data-src") }
            if (src.isNotEmpty() && !src.contains("youtube") && !src.contains("google")) {
                val formattedSrc = if (src.startsWith("//")) "https:$src" else src
                if (!iframes.contains(formattedSrc)) {
                    iframes.add(formattedSrc)
                    dubbingIframes.add(formattedSrc)
                    subtitleIframes.add(formattedSrc)
                }
            }
        }

        // 3. Dizi bölümlerini tespit et (dizi ise)
        val epRegex = Regex("""/([a-zA-Z0-9_\-]+)-(\d+)-sezon-(\d+)-bolum""")
        doc.select("a[href*='-sezon-'][href*='-bolum']").forEach { aTag ->
            val href = aTag.attr("href")
            val match = epRegex.find(href)
            if (match != null) {
                isSeries = true
                val sNum = match.groupValues[2].toIntOrNull() ?: 1
                val epNum = match.groupValues[3].toIntOrNull() ?: 1
                val epTitle = aTag.text().ifEmpty { "$epNum. Bölüm" }
                val fullEpUrl = if (href.startsWith("http")) href else if (href.startsWith("/")) "$baseUrl$href" else "$baseUrl/$href"

                val episodeItems = seasonsMap.getOrPut(sNum) { mutableListOf() }
                if (episodeItems.none { it.url == fullEpUrl }) {
                    episodeItems.add(Episode(epNum, epTitle, fullEpUrl))
                }
            }
        }

        val parsedSeasons = seasonsMap.map { (sNum, epList) ->
            Season(seasonNumber = sNum, name = "$sNum. Sezon", episodes = epList)
        }

        val languages = mutableListOf<String>()
        if (dubbingIframes.isNotEmpty()) languages.add("Türkçe Dublaj")
        if (subtitleIframes.isNotEmpty()) languages.add("Türkçe Altyazı")
        if (languages.isEmpty() && iframes.isNotEmpty()) {
            languages.add("Türkçe Dublaj")
            languages.add("Türkçe Altyazı")
        }

        val cleanPoster = PosterUrlUtils.normalize(poster, name, true)

        MovieDetail(
            title = title,
            description = description,
            posterUrl = cleanPoster,
            iframes = iframes,
            isSeries = isSeries,
            seasons = parsedSeasons,
            provider = name,
            languages = languages,
            dubbingIframes = dubbingIframes,
            subtitleIframes = subtitleIframes,
            hasDub = dubbingIframes.isNotEmpty(),
            hasSubtitle = subtitleIframes.isNotEmpty()
        )
    }

    override suspend fun getEpisodeSources(episodeUrl: String): EpisodeSources = withContext(Dispatchers.IO) {
        val detail = getMovieDetail(episodeUrl)
        EpisodeSources(
            iframes = detail.iframes,
            dubbingIframes = detail.dubbingIframes,
            subtitleIframes = detail.subtitleIframes,
            hasDub = detail.hasDub,
            hasSubtitle = detail.hasSubtitle
        )
    }

    override suspend fun getEpisodeIframes(episodeUrl: String): List<String> = withContext(Dispatchers.IO) {
        getEpisodeSources(episodeUrl).iframes
    }

    private companion object {
        const val TAG = "Hdfilmcehennemi"
    }
}
