package tv.newtv.repository

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import tv.newtv.data.local.ChannelDao
import tv.newtv.data.local.ChannelEntity
import tv.newtv.data.local.ChannelStatus
import tv.newtv.data.local.InitialData
import tv.newtv.data.local.IptvPerformanceSettings
import tv.newtv.data.local.IptvSettingsManager
import tv.newtv.utils.M3uParser
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class IptvRepository(
    private val channelDao: ChannelDao,
    private val okHttpClient: OkHttpClient,
    private val context: Context? = null
) {
    private data class ChannelAggregate(
        var bestName: String,
        var bestLogo: String?,
        val groupTitle: String,
        val canonicalKey: String,
        val streamUrls: LinkedHashSet<String> = LinkedHashSet()
    )

    /**
     * Tüm M3U kaynaklarını (varsayılan + GitHub'dan keşfedilenler) indirir.
     * Sadece Spor ve Ulusal kanalları filtreler.
     * Aynı kanalları canonicalKey üzerinden birleştirerek tekil hale getirir,
     * tüm yedek yayın linklerini toplar.
     */
    suspend fun syncInitialPlaylists(extraSources: List<String> = emptyList()) = withContext(Dispatchers.IO) {
        val aggregatedMap = LinkedHashMap<String, ChannelAggregate>()

        val customSources = context?.let { IptvSettingsManager.getCustomSources(it) } ?: emptyList()
        val allSources = (InitialData.iptvSources + customSources + extraSources).filter { it.isNotBlank() }.distinct()

        val deferredList = coroutineScope {
            allSources.map { url ->
                async(Dispatchers.IO) {
                    val channelsForSource = mutableListOf<ChannelEntity>()
                    try {
                        val request = Request.Builder().url(url).build()
                        val response = okHttpClient.newCall(request).execute()
                        if (response.isSuccessful) {
                            response.body?.byteStream()?.let { inputStream ->
                                M3uParser.parse(inputStream, url)
                                    .catch { e -> e.printStackTrace() }
                                    .collect { parsed ->
                                        channelsForSource.add(parsed)
                                    }
                            }
                        }
                        response.close()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    channelsForSource
                }
            }
        }

        val allResults = deferredList.awaitAll()
        for (sourceChannels in allResults) {
            for (parsedChannel in sourceChannels) {
                val key = parsedChannel.canonicalKey
                if (key.isNotEmpty()) {
                    val existing = aggregatedMap[key]
                    if (existing == null) {
                        aggregatedMap[key] = ChannelAggregate(
                            bestName = parsedChannel.name,
                            bestLogo = parsedChannel.logoUrl,
                            groupTitle = parsedChannel.groupTitle ?: "Ulusal Kanallar",
                            canonicalKey = key,
                            streamUrls = LinkedHashSet(listOf(parsedChannel.streamUrl))
                        )
                    } else {
                        // Yedek URL'i listeye ekle
                        existing.streamUrls.add(parsedChannel.streamUrl)

                        // Logo yoksa yeni logoyu al
                        if (existing.bestLogo.isNullOrEmpty() && !parsedChannel.logoUrl.isNullOrEmpty()) {
                            existing.bestLogo = parsedChannel.logoUrl
                        }

                        // İsim kalitesini koru/iyileştir (HD/FHD içeren ismi tercih et)
                        if (!existing.bestName.contains("HD", ignoreCase = true) &&
                            parsedChannel.name.contains("HD", ignoreCase = true)) {
                            existing.bestName = parsedChannel.name
                        }
                    }
                }
            }
        }

        if (aggregatedMap.isNotEmpty()) {
            val deduplicatedEntities = aggregatedMap.values.map { aggregate ->
                val urls = aggregate.streamUrls.toList()
                val urlsJson = JSONArray(urls).toString()
                ChannelEntity(
                    name = aggregate.bestName,
                    logoUrl = aggregate.bestLogo,
                    groupTitle = aggregate.groupTitle,
                    streamUrl = urls.firstOrNull() ?: "",
                    sourceListUrl = "MULTI_SOURCE",
                    canonicalKey = aggregate.canonicalKey,
                    streamUrlsJson = urlsJson,
                    sourceCount = urls.size,
                    isFavorite = false,
                    status = ChannelStatus.UNKNOWN
                )
            }

            channelDao.deleteAllChannels()
            // Parçalı ekleme (Memory-safe)
            deduplicatedEntities.chunked(400).forEach { batch ->
                channelDao.insertChannels(batch)
            }
        }
    }

    private fun getCustomTimeoutClient(): OkHttpClient {
        val settings = context?.let { IptvSettingsManager.getSettings(it) } ?: IptvPerformanceSettings()
        val timeout = settings.timeoutSec.coerceIn(2, 20).toLong()
        return tv.newtv.network.OkHttpClientProvider.getFastPingOkHttpClient().newBuilder()
            .connectTimeout(timeout, TimeUnit.SECONDS)
            .readTimeout(timeout, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Tek bir URL'in erişilebilir olup olmadığını ve yanıt gecikmesini (ms) test eder.
     */
    fun pingUrlWithLatency(streamUrl: String): Pair<Boolean, Long> {
        val client = getCustomTimeoutClient()
        val startTime = System.currentTimeMillis()
        try {
            val headRequest = Request.Builder()
                .url(streamUrl)
                .head()
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .header("Accept", "*/*")
                .build()

            client.newCall(headRequest).execute().use { response ->
                val latency = System.currentTimeMillis() - startTime
                val code = response.code
                if (code in 200..399 || code == 405 || code == 403) {
                    return Pair(true, latency)
                }
            }

            val getRequest = Request.Builder()
                .url(streamUrl)
                .get()
                .header("Range", "bytes=0-128")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .build()

            client.newCall(getRequest).execute().use { getResp ->
                val latency = System.currentTimeMillis() - startTime
                val getCode = getResp.code
                if (getCode in 200..399 || getCode == 403) {
                    return Pair(true, latency)
                }
            }
        } catch (_: Throwable) {}
        val latency = System.currentTimeMillis() - startTime
        return Pair(false, latency)
    }

    private fun pingUrl(streamUrl: String): Boolean {
        return pingUrlWithLatency(streamUrl).first
    }

    /**
     * Kanalın durumunu test eder: İlk kaynak çalışıyorsa hemen ACTIVE döner.
     * İlk kaynak çalışmıyorsa diğer yedek kaynakları (en fazla 2 yedek) test eder.
     */
    suspend fun checkChannelStatus(channel: ChannelEntity): ChannelStatus = withContext(Dispatchers.IO) {
        val urls = channel.getStreamUrls()
        val toCheck = if (urls.size > 2) urls.take(2) else urls
        for (url in toCheck) {
            if (pingUrl(url)) {
                return@withContext ChannelStatus.ACTIVE
            }
        }
        ChannelStatus.OFFLINE
    }

    /**
     * Kanala ait tüm kaynakları test eder ve her birinin durumunu ve gecikme süresini döner.
     */
    suspend fun testChannelAllSources(channel: ChannelEntity): List<Pair<String, Pair<Boolean, Long>>> = withContext(Dispatchers.IO) {
        channel.getStreamUrls().map { url ->
            val result = pingUrlWithLatency(url)
            url to result
        }
    }

    /**
     * Kanalları IptvSettingsManager'daki eşzamanlı kanal test sayısıyla (varsayılan 15) doğrular.
     */
    suspend fun checkChannelsBatch(
        channels: List<ChannelEntity>,
        onProgress: (verified: Int, total: Int, channelId: Int, status: ChannelStatus) -> Unit = { _, _, _, _ -> }
    ): List<Pair<Int, ChannelStatus>> = coroutineScope {
        val settings = context?.let { IptvSettingsManager.getSettings(it) } ?: IptvPerformanceSettings()
        val semaphore = Semaphore(settings.concurrentTestCount.coerceIn(1, 30))
        val progressCount = AtomicInteger(0)
        val total = channels.size

        val deferreds = channels.map { channel ->
            async(Dispatchers.IO) {
                val status = semaphore.withPermit {
                    checkChannelStatus(channel)
                }
                val current = progressCount.incrementAndGet()
                onProgress(current, total, channel.id, status)
                channel.id to status
            }
        }
        deferreds.awaitAll()
    }
}
