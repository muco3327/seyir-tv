package tv.newtv.scraper

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import tv.newtv.data.models.MovieDetail
import tv.newtv.data.models.MovieItem
import tv.newtv.data.models.VodCategory

class FullhdfilmizleseneScraper(private val client: OkHttpClient) : MovieScraper {
    override val name = "FullHDFilmİzlesene"
    private val baseUrl = "https://www.fullhdfilmizlesene.now"
    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun fetchDocument(url: String): Document {
        val formattedUrl = if (url.startsWith("http")) url else "$baseUrl$url"
        val request = Request.Builder()
            .url(formattedUrl)
            .header("User-Agent", userAgent)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8")
            .build()
        
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
        val html = response.body?.string() ?: ""
        return Jsoup.parse(html, formattedUrl)
    }

    private fun parseMoviesFromDoc(doc: Document): List<MovieItem> {
        val items = mutableListOf<MovieItem>()
        val seen = mutableSetOf<String>()
        
        doc.select("ul.mov-list > li, div.poster-item, div.film-item, article.item").forEach { element ->
            val aTag = element.selectFirst("a") ?: return@forEach
            val title = aTag.attr("title").ifEmpty { element.selectFirst(".title, h2, h3")?.text() ?: "" }.trim()
            val url = aTag.attr("href")
            
            var posterUrl = ""
            val img = element.selectFirst("img")
            if (img != null) {
                posterUrl = img.attr("data-src").ifEmpty { img.attr("src") }
            }
            if (posterUrl.startsWith("//")) posterUrl = "https:$posterUrl"
            else if (posterUrl.startsWith("/")) posterUrl = "$baseUrl$posterUrl"
            
            val fullUrl = if (url.startsWith("http")) url else "$baseUrl$url"
            
            if (title.isNotEmpty() && url.isNotEmpty() && seen.add(fullUrl)) {
                items.add(MovieItem(title = title, url = fullUrl, posterUrl = posterUrl, provider = name))
            }
        }
        return items
    }

    override suspend fun getCategories(page: Int): List<VodCategory<MovieItem>> = withContext(Dispatchers.IO) {
        val categories = mutableListOf<VodCategory<MovieItem>>()
        try {
            val doc = fetchDocument(baseUrl)
            
            val homeMovies = parseMoviesFromDoc(doc)
            if (homeMovies.isNotEmpty()) {
                categories.add(VodCategory("Yeni Eklenen Filmler", homeMovies.take(20)))
            }
            
            val popularUrl = "$baseUrl/en-cok-izlenen-filmler"
            try {
                val popDoc = fetchDocument(popularUrl)
                val popMovies = parseMoviesFromDoc(popDoc)
                if (popMovies.isNotEmpty()) {
                    categories.add(VodCategory("Popüler Filmler", popMovies.take(20)))
                }
            } catch (e: Exception) { android.util.Log.d("FullHDScraper", "Populer failed", e) }

        } catch (e: Exception) {
            e.printStackTrace()
        }
        categories
    }

    override suspend fun search(query: String, page: Int): List<MovieItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MovieItem>()
        try {
            val searchUrl = "$baseUrl/arama/${java.net.URLEncoder.encode(query, "UTF-8")}"
            val doc = fetchDocument(searchUrl)
            items.addAll(parseMoviesFromDoc(doc))
        } catch (e: Exception) {
            e.printStackTrace()
        }
        items
    }

    override suspend fun getMovieDetail(movieUrl: String): MovieDetail = withContext(Dispatchers.IO) {
        val doc = fetchDocument(movieUrl)
        
        val title = doc.selectFirst("h1")?.text() ?: ""
        val description = doc.selectFirst(".ozet, .summary, p[itemprop=description]")?.text() ?: ""
        
        var posterUrl = doc.selectFirst(".poster img, .film-poster img")?.let { img ->
            img.attr("data-src").ifEmpty { img.attr("src") }
        } ?: ""
        if (posterUrl.startsWith("//")) posterUrl = "https:$posterUrl"
        
        val iframes = mutableListOf<String>()
        val dubbingIframes = mutableListOf<String>()
        val subtitleIframes = mutableListOf<String>()
        
        doc.select("iframe").forEach { iframe ->
            val src = iframe.attr("data-src").ifEmpty { iframe.attr("src") }
            if (src.isNotEmpty() && !src.contains("youtube") && !src.contains("google")) {
                val formattedSrc = if (src.startsWith("//")) "https:$src" else src
                iframes.add(formattedSrc)
            }
        }
        
        doc.select(".lang-options a, .source-list li").forEach { tab ->
            val langText = tab.text().lowercase()
            val dataSrc = tab.attr("data-src").ifEmpty { tab.attr("data-url") }
            if (dataSrc.isNotEmpty()) {
                val formatted = if (dataSrc.startsWith("//")) "https:$dataSrc" else dataSrc
                if (!iframes.contains(formatted)) iframes.add(formatted)
                
                if (langText.contains("dublaj") || langText.contains("tr")) {
                    if (!dubbingIframes.contains(formatted)) dubbingIframes.add(formatted)
                }
                if (langText.contains("altyaz") || langText.contains("en")) {
                    if (!subtitleIframes.contains(formatted)) subtitleIframes.add(formatted)
                }
            }
        }
        
        if (dubbingIframes.isEmpty() && iframes.isNotEmpty()) dubbingIframes.addAll(iframes)
        if (subtitleIframes.isEmpty() && iframes.isNotEmpty()) subtitleIframes.addAll(iframes)
        
        val languages = mutableListOf<String>()
        if (dubbingIframes.isNotEmpty()) languages.add("Türkçe Dublaj")
        if (subtitleIframes.isNotEmpty()) languages.add("Türkçe Altyazı")

        MovieDetail(
            title = title,
            description = description,
            posterUrl = posterUrl,
            iframes = iframes.distinct(),
            isSeries = false,
            provider = name,
            languages = languages,
            dubbingIframes = dubbingIframes.distinct(),
            subtitleIframes = subtitleIframes.distinct(),
            hasDub = dubbingIframes.isNotEmpty(),
            hasSubtitle = subtitleIframes.isNotEmpty()
        )
    }
}
