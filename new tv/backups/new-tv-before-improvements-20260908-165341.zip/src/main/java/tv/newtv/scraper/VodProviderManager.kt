package tv.newtv.scraper

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import tv.newtv.data.models.MovieItem
import tv.newtv.data.models.SeriesItem
import tv.newtv.network.OkHttpClientProvider

class VodProviderManager(private val client: OkHttpClient = OkHttpClientProvider.getScraperOkHttpClient()) {

    val hdfilmcehennemi = HdfilmcehennemiScraper(client)
    val filmModu = FilmModuScraper(client)
    val jetfilm = JetfilmScraper(client)
    val fullHdFilm = FullhdfilmizleseneScraper(client)

    val dizilla = DizillaScraper(client)
    val sezonlukDizi = SezonlukDiziScraper(client)
    val diziwatch = DiziwatchScraper(client)
    val dizigom = DizigomScraper(client)

    val movieScrapers: List<MovieScraper> = listOf(fullHdFilm, hdfilmcehennemi, filmModu, jetfilm)
    val seriesScrapers: List<SeriesScraper> = listOf(diziwatch, dizigom, dizilla, sezonlukDizi)

    fun getMovieScraper(name: String?): MovieScraper {
        return movieScrapers.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: fullHdFilm
    }

    fun getSeriesScraper(name: String?): SeriesScraper {
        return seriesScrapers.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: diziwatch
    }

    fun getMovieScraperForUrl(url: String): MovieScraper {
        return when {
            url.contains("filmmodu", ignoreCase = true) -> filmModu
            url.contains("jetfilm", ignoreCase = true) || url.contains("fullhdfilmizle", ignoreCase = true) && !url.contains("fullhdfilmizlesene") -> jetfilm
            url.contains("fullhdfilmizlesene", ignoreCase = true) -> fullHdFilm
            url.contains("selcukflix", ignoreCase = true) || url.contains("hdfilmcehennemi", ignoreCase = true) -> hdfilmcehennemi
            else -> fullHdFilm
        }
    }

    fun getSeriesScraperForUrl(url: String): SeriesScraper {
        return when {
            url.contains("sezonlukdizi", ignoreCase = true) -> sezonlukDizi
            url.contains("dizilla", ignoreCase = true) -> dizilla
            url.contains("diziwatch", ignoreCase = true) -> diziwatch
            url.contains("dizigom", ignoreCase = true) -> dizigom
            else -> diziwatch
        }
    }

    /**
     * Cross-Provider Arama: Tüm aktif film kaynaklarında paralel arama yapar ve sonuçları birleştirir.
     */
    suspend fun searchAllMovies(query: String): List<MovieItem> = withContext(Dispatchers.IO) {
        coroutineScope {
            val deferreds = movieScrapers.map { scraper ->
                async {
                    try {
                        scraper.search(query)
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            }
            val results = deferreds.awaitAll().flatten()
            val seen = mutableSetOf<String>()
            val uniqueResults = mutableListOf<MovieItem>()
            for (item in results) {
                // Başlık ve sağlayıcı kombinasyonu ile mükerrer kontrolü
                val key = "${item.title.lowercase()}_${item.provider}"
                if (seen.add(key)) {
                    uniqueResults.add(item)
                }
            }
            uniqueResults
        }
    }

    /**
     * Cross-Provider Arama: Tüm aktif dizi kaynaklarında paralel arama yapar ve sonuçları birleştirir.
     */
    suspend fun searchAllSeries(query: String): List<SeriesItem> = withContext(Dispatchers.IO) {
        coroutineScope {
            val deferreds = seriesScrapers.map { scraper ->
                async {
                    try {
                        scraper.search(query)
                    } catch (e: Exception) {
                        emptyList()
                    }
                }
            }
            val results = deferreds.awaitAll().flatten()
            val seen = mutableSetOf<String>()
            val uniqueResults = mutableListOf<SeriesItem>()
            for (item in results) {
                val key = "${item.title.lowercase()}_${item.provider}"
                if (seen.add(key)) {
                    uniqueResults.add(item)
                }
            }
            uniqueResults
        }
    }
}
