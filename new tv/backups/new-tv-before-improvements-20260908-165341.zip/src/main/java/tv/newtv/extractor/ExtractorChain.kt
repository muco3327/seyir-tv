package tv.newtv.extractor

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.newtv.data.models.VideoSource

class ExtractorChain(private val client: OkHttpClient) {

    // Video çözücü sunucular (Vidmoly, Pichive, Sibnet, Okru, Vidmixi, Vidload vb.)
    private val extractors = listOf(
        VidmolyExtractor(client),
        PichiveExtractor(client),
        SibnetExtractor(client),
        OkruExtractor(client),
        VidmixiExtractor(client),
        VidloadExtractor(client)
    )

    /**
     * Gelen iframe kaynaklarını sırayla dener. İlk başarılı çözülen
     * video kaynağını döndürür. (Hata Toleranslı Fallback Zinciri)
     */
    suspend fun resolveSource(iframeUrls: List<String>): VideoSource? = withContext(Dispatchers.IO) {
        val all = resolveAllSources(iframeUrls)
        all.firstOrNull()
    }

    /**
     * Canlı TV'deki çoklu kaynak mantığını VOD'a (Film ve Dizi) getiren metod.
     * Tüm iframe ve sunucu kaynaklarını çözümler, çalışan TÜM alternatif video kaynaklarını listeler.
     */
    suspend fun resolveAllSources(iframeUrls: List<String>): List<VideoSource> = withContext(Dispatchers.IO) {
        val results = mutableListOf<VideoSource>()
        val seenUrls = mutableSetOf<String>()

        for ((index, url) in iframeUrls.withIndex()) {
            try {
                val extractor = extractors.find { it.canHandle(url) }
                val resolved: VideoSource? = if (extractor != null) {
                    val src = extractor.extract(url)
                    if (src != null) {
                        val hostLabel = when {
                            extractor.host.contains("vidmoly", ignoreCase = true) -> "Vidmoly"
                            extractor.host.contains("pichive", ignoreCase = true) -> "Pichive"
                            extractor.host.contains("vidmixi", ignoreCase = true) -> "Vidmixi"
                            extractor.host.contains("vidload", ignoreCase = true) -> "Vidload"
                            else -> extractor.host.replaceFirstChar { it.uppercase() }
                        }
                        src.copy(serverName = "$hostLabel Sunucusu")
                    } else null
                } else {
                    val direct = extractDirect(url)
                    if (direct != null) {
                        direct.copy(serverName = "Doğrudan Akış ${index + 1}")
                    } else null
                }

                if (resolved != null && seenUrls.add(resolved.url)) {
                    val finalSource = if (resolved.serverName.isBlank()) {
                        resolved.copy(serverName = "Sunucu ${results.size + 1}")
                    } else resolved
                    results.add(finalSource)
                }
            } catch (e: Exception) {
                android.util.Log.w("ExtractorChain", "Extractor failed for url: $url", e)
            }
        }
        results
    }

    private fun extractDirect(url: String): VideoSource? {
        val clean = url.trim()
        if (clean.contains(".m3u8", ignoreCase = true)) {
            return VideoSource(
                url = clean,
                mimeType = androidx.media3.common.MimeTypes.APPLICATION_M3U8,
                serverName = "HLS Akışı"
            )
        } else if (clean.contains(".mp4", ignoreCase = true)) {
            return VideoSource(
                url = clean,
                mimeType = androidx.media3.common.MimeTypes.VIDEO_MP4,
                serverName = "MP4 Akışı"
            )
        }
        return null
    }
}
