package tv.newtv.scraper

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import tv.newtv.data.models.Episode
import tv.newtv.data.models.MovieDetail
import tv.newtv.data.models.MovieItem
import tv.newtv.data.models.Season
import tv.newtv.data.models.VodCategory
import tv.newtv.utils.NextJsAesDecryptor

import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody

class HdfilmcehennemiScraper(private val client: OkHttpClient) : MovieScraper {
    override val name = "HDFilmcehennemi"
    private val baseUrl = "https://www.hdfilmcehennemi.nl"
    private val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun fetchDocument(url: String): Document {
        val formattedUrl = if (url.startsWith("http")) url else if (url.startsWith("/")) "$baseUrl$url" else "$baseUrl/$url"
        val request = Request.Builder()
            .url(formattedUrl)
            .header("User-Agent", userAgent)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7")
            .build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) throw Exception("Failed to fetch: ${response.code}")
        val html = response.body?.string() ?: ""
        return Jsoup.parse(html, formattedUrl)
    }

    private suspend fun fetchAndDecrypt(url: String): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val formattedUrl = if (url.startsWith("http")) url else if (url.startsWith("/")) "$baseUrl$url" else "$baseUrl/$url"
            val request = Request.Builder()
                .url(formattedUrl)
                .header("User-Agent", userAgent)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("Accept-Language", "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7")
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val html = response.body?.string() ?: ""
                response.close()
                NextJsAesDecryptor.extractAndDecryptFromHtml(html)
            } else {
                response.close()
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseMovieItem(obj: JSONObject, seen: MutableSet<String>): MovieItem? {
        val slug = obj.optString("used_slug").ifEmpty { obj.optString("slug") }
        val title = obj.optString("original_title")
            .ifEmpty { obj.optString("culture_title") }
            .ifEmpty { obj.optString("title") }
            .trim()

        var poster = obj.optString("poster_url")
            .ifEmpty { obj.optString("face_url") }
            .ifEmpty { obj.optString("object_poster_url") }
            .trim()

        // Zorunlu Doğrulama: Gerçek bir film olmalı, taksonomi veya boş afiş olmamalı
        if (poster.length < 5 || title.length < 2 || slug.isEmpty()) return null
        if (slug.contains("/yil/") || slug.contains("/ulke/") || slug.contains("/kategori/") || slug.contains("/film-kategori/")) return null

        // URL Temizleme & Protokol Düzeltme
        if (poster.startsWith("//")) {
            poster = "https:$poster"
        } else if (poster.startsWith("/")) {
            poster = "$baseUrl$poster"
        }

        // Google AMP Proxy'sini kaldır ve doğrudan güvenilir Macellan CDN'e bağla (Yüklenemeyen afiş sorununu çözer)
        poster = poster.replace("https://images-macellan-online.cdn.ampproject.org/i/s/", "https://")
            .replace("http://images-macellan-online.cdn.ampproject.org/i/s/", "https://")

        // Kırık / Placeholder afişleri filtrele
        if (poster.contains("dizilla-og.jpg", ignoreCase = true) ||
            poster.contains("placeholder", ignoreCase = true) ||
            poster.contains("no-poster", ignoreCase = true)) {
            return null
        }

        val fullUrl = if (slug.startsWith("http")) slug else if (slug.startsWith("/")) "$baseUrl$slug" else "$baseUrl/$slug"
        if (seen.add(fullUrl)) {
            return MovieItem(title = title, url = fullUrl, posterUrl = poster, provider = name)
        }
        return null
    }

    private fun parseMoviesFromJsonArray(arr: JSONArray?, seen: MutableSet<String> = mutableSetOf()): List<MovieItem> {
        val list = mutableListOf<MovieItem>()
        if (arr == null) return list

        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            parseMovieItem(obj, seen)?.let { list.add(it) }
        }
        return list
    }

    private fun parseMoviesFromJsonObject(json: JSONObject?, seen: MutableSet<String> = mutableSetOf()): List<MovieItem> {
        val list = mutableListOf<MovieItem>()
        if (json == null) return list

        // Filtrelenecek taksonomi ve filtre açılır menü anahtarları (fake filmler oluşmasını önler)
        val ignoredKeys = setOf(
            "yearList", "countryList", "yearListSeries", "countryListSeries",
            "getCategoriesByGroup", "getCategoriesByGroupSeries", "contentItem", "content",
            "siteSettings", "adsWithKeys"
        )

        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            if (ignoredKeys.contains(key)) continue

            val arr = json.optJSONArray(key)
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    parseMovieItem(obj, seen)?.let { list.add(it) }
                }
            } else {
                val subObj = json.optJSONObject(key)
                if (subObj != null) {
                    val subArr = subObj.optJSONArray("result")
                    if (subArr != null) {
                        for (i in 0 until subArr.length()) {
                            val obj = subArr.optJSONObject(i) ?: continue
                            parseMovieItem(obj, seen)?.let { list.add(it) }
                        }
                    } else if (key == "RelatedResults") {
                        val rKeys = subObj.keys()
                        while (rKeys.hasNext()) {
                            val rk = rKeys.next()
                            val nested = subObj.optJSONObject(rk)
                            val nestedArr = nested?.optJSONArray("result")
                            if (nestedArr != null) {
                                for (j in 0 until nestedArr.length()) {
                                    val obj = nestedArr.optJSONObject(j) ?: continue
                                    parseMovieItem(obj, seen)?.let { list.add(it) }
                                }
                            }
                        }
                    }
                }
            }
        }
        return list
    }

    private fun filterJsonByGenres(arrays: List<JSONArray?>, genres: List<String>): List<MovieItem> {
        val list = mutableListOf<MovieItem>()
        val seen = mutableSetOf<String>()

        for (arr in arrays) {
            if (arr == null) continue
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val categories = obj.optString("categories")
                val matchesGenre = genres.any { g -> categories.contains(g, ignoreCase = true) }
                if (matchesGenre) {
                    parseMovieItem(obj, seen)?.let { list.add(it) }
                }
            }
        }
        return list
    }

    private fun parseMoviesFromDoc(doc: Document): List<MovieItem> {
        val list = mutableListOf<MovieItem>()
        val seen = mutableSetOf<String>()

        // Hem film/ hem de /film/ kalıplarını yakalar
        doc.select("a[href*='film/']").forEach { aTag ->
            val href = aTag.attr("href")
            val imgTag = aTag.selectFirst("img") ?: return@forEach
            val rawTitle = aTag.selectFirst("h3")?.text()
                ?: imgTag.attr("alt").ifEmpty { aTag.attr("title") }.ifEmpty { aTag.text() }
            val title = rawTitle.replace(" izle", "", ignoreCase = true).trim()
            var poster = imgTag.attr("src").ifEmpty { imgTag.attr("data-src") }.trim()
            if (poster.startsWith("//")) poster = "https:$poster"
            else if (poster.startsWith("/")) poster = "$baseUrl$poster"

            poster = poster.replace("https://images-macellan-online.cdn.ampproject.org/i/s/", "https://")
                .replace("http://images-macellan-online.cdn.ampproject.org/i/s/", "https://")

            val fullUrl = if (href.startsWith("http")) href else if (href.startsWith("/")) "$baseUrl$href" else "$baseUrl/$href"

            if (title.isNotEmpty() && !title.equals("film", ignoreCase = true) && poster.length > 5 && seen.add(fullUrl)) {
                list.add(MovieItem(title, fullUrl, poster))
            }
        }
        return list
    }

    override suspend fun getRecent(page: Int): List<MovieItem> = withContext(Dispatchers.IO) {
        val categories = getCategories(page)
        categories.flatMap { it.items }.distinctBy { it.url }
    }

    override suspend fun getCategories(page: Int): List<VodCategory<MovieItem>> = withContext(Dispatchers.IO) {
        val categories = mutableListOf<VodCategory<MovieItem>>()

        try {
            val docUrl = if (page > 1) "$baseUrl/film-izle?page=$page" else baseUrl
            val doc = fetchDocument(docUrl)
            val html = doc.html()
            
            val decrypted = NextJsAesDecryptor.extractAndDecryptFromHtml(html)
            if (decrypted != null) {
                val catMap = mutableMapOf<String, JSONArray>()
                val keys = decrypted.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (key.startsWith("getCategoriesByGroup") || key.startsWith("getMovieList")) {
                        val obj = decrypted.optJSONObject(key)
                        val title = obj?.optString("title") ?: "Filmler"
                        val arr = obj.optJSONArray("result")
                        if (arr != null && arr.length() > 0) {
                            catMap[title] = arr
                        }
                    }
                }

                for ((title, jsonArr) in catMap) {
                    val movies = parseMoviesFromJsonArray(jsonArr)
                    if (movies.isNotEmpty()) {
                        categories.add(VodCategory(title, movies))
                    }
                }
            }

            if (categories.isEmpty()) {
                val homeItems = parseMoviesFromDoc(doc)
                if (homeItems.isNotEmpty()) {
                    categories.add(VodCategory("Filmler (Sayfa $page)", homeItems))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        categories
    }

    override suspend fun search(query: String, page: Int): List<MovieItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MovieItem>()
        val seen = mutableSetOf<String>()
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext items

        try {
            val encodedQuery = java.net.URLEncoder.encode(trimmed, "UTF-8")
            val searchUrl = "$baseUrl/api/bg/searchContent?searchterm=$encodedQuery"
            val jsonPayload = org.json.JSONObject().put("searchterm", trimmed).toString()
            val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
            val requestBody = jsonPayload.toRequestBody(mediaType)

            val request = Request.Builder()
                .url(searchUrl)
                .post(requestBody)
                .header("User-Agent", userAgent)
                .header("Referer", "$baseUrl/")
                .header("Accept", "application/json, text/plain, */*")
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val bodyStr = response.body?.string() ?: ""
                val jsonResponse = org.json.JSONObject(bodyStr)
                val encryptedResponse = jsonResponse.optString("response")
                if (encryptedResponse.isNotEmpty()) {
                    val decrypted = NextJsAesDecryptor.decrypt(encryptedResponse)
                    val resultArr = decrypted?.optJSONArray("result")
                    if (resultArr != null) {
                        for (i in 0 until resultArr.length()) {
                            val obj = resultArr.optJSONObject(i) ?: continue
                            val slug = obj.optString("used_slug").ifEmpty { obj.optString("slug") }
                            val title = obj.optString("object_name").ifEmpty { obj.optString("title") }.trim()
                            var poster = obj.optString("object_poster_url").ifEmpty { obj.optString("poster_url") }
                            if (poster.startsWith("/")) poster = "$baseUrl$poster"
                            val fullUrl = if (slug.startsWith("http")) slug else if (slug.startsWith("/")) "$baseUrl$slug" else "$baseUrl/$slug"

                            val usedType = obj.optString("used_type")
                            val isMovie = usedType.equals("Movie", ignoreCase = true) || slug.contains("film") || !slug.contains("dizi")

                            if (isMovie && title.isNotEmpty() && slug.isNotEmpty() && seen.add(fullUrl)) {
                                items.add(MovieItem(title = title, url = fullUrl, posterUrl = poster))
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Fallback: Yerel listedeki filmlerden arama terimini içerenleri de ekle
        if (items.isEmpty()) {
            val localMovies = getRecent()
            val matched = localMovies.filter { it.title.contains(trimmed, ignoreCase = true) }
            items.addAll(matched.filter { seen.add(it.url) })
        }

        items
    }

    override suspend fun getMovieDetail(movieUrl: String): MovieDetail = withContext(Dispatchers.IO) {
        val doc = fetchDocument(movieUrl)
        val html = doc.html()

        var title = doc.selectFirst("h1")?.text()?.replace(" izle", "", ignoreCase = true)?.trim() ?: ""
        var description = doc.selectFirst("meta[name=description]")?.attr("content") ?: ""
        var poster = doc.selectFirst("img[src*='poster'], .poster img, img")?.attr("src") ?: ""
        val iframes = mutableListOf<String>()
        val dubbingIframes = mutableListOf<String>()
        val subtitleIframes = mutableListOf<String>()
        var isSeries = false
        val seasonsMap = sortedMapOf<Int, MutableList<Episode>>()

        // 1. Şifreli Next.js verisinden film veya dizi detayını ve oynatıcı kaynaklarını çek
        val decrypted = NextJsAesDecryptor.extractAndDecryptFromHtml(html)
        if (decrypted != null) {
            val contentItem = decrypted.optJSONObject("contentItem")
            if (contentItem != null) {
                val itemTitle = contentItem.optString("original_title").ifEmpty { contentItem.optString("culture_title") }
                if (itemTitle.isNotEmpty()) title = itemTitle
                val itemDesc = contentItem.optString("description")
                if (itemDesc.isNotEmpty()) description = itemDesc
                val itemPoster = contentItem.optString("poster_url").ifEmpty { contentItem.optString("face_url") }
                if (itemPoster.isNotEmpty()) poster = itemPoster

                val usedType = contentItem.optString("used_type")
                val isSeriesFlag = contentItem.optInt("is_series", 0)
                if (usedType.equals("Series", ignoreCase = true) || usedType.equals("Serie", ignoreCase = true) || isSeriesFlag == 1) {
                    isSeries = true
                }
            }

            val related = decrypted.optJSONObject("RelatedResults")
            if (related != null) {
                // A) Dizi sezon ve bölümlerini kontrol et
                val seasonData = related.optJSONObject("getSerieSeasonAndEpisodes")?.optJSONArray("result")
                if (seasonData != null && seasonData.length() > 0) {
                    isSeries = true
                    for (i in 0 until seasonData.length()) {
                        val sObj = seasonData.optJSONObject(i) ?: continue
                        val sNum = sObj.optInt("season_no", i + 1)
                        val epList = sObj.optJSONArray("episodes") ?: continue

                        val episodeItems = seasonsMap.getOrPut(sNum) { mutableListOf() }
                        for (j in 0 until epList.length()) {
                            val epObj = epList.optJSONObject(j) ?: continue
                            val epNum = epObj.optInt("episode_no", j + 1)
                            val epTitle = epObj.optString("episode_text").ifEmpty { "$epNum. Bölüm" }
                            val epSlug = epObj.optString("used_slug")
                            val epUrl = if (epSlug.startsWith("http")) epSlug else if (epSlug.startsWith("/")) "$baseUrl$epSlug" else "$baseUrl/$epSlug"
                            episodeItems.add(Episode(epNum, epTitle, epUrl))
                        }
                    }
                }

                // B) Oynatıcı / Film kaynaklarını topla (Part ve Source içeren tüm anahtarlar)
                val iframeSrcRegex = Regex("""src\s*=\s*["']([^"']+)["']""")
                val urlRegex = Regex("""https?://[^\s"'<>]+""")

                val keys = related.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (key.contains("Source", ignoreCase = true) || key.contains("Part", ignoreCase = true)) {
                        val partObj = related.optJSONObject(key)
                        val resultArr = partObj?.optJSONArray("result")
                        if (resultArr != null) {
                            for (i in 0 until resultArr.length()) {
                                val sObj = resultArr.optJSONObject(i) ?: continue
                                val langName = sObj.optString("language_name").lowercase()
                                val srcName = sObj.optString("source_name").lowercase()
                                val isDub = langName.contains("dublaj") || srcName.contains("dublaj") || key.contains("dublaj", ignoreCase = true)
                                val isSub = langName.contains("altyaz") || srcName.contains("altyaz") || key.contains("altyaz", ignoreCase = true)

                                val extracted = mutableListOf<String>()

                                val directSourceUrl = sObj.optString("source_url").ifEmpty { sObj.optString("url") }
                                if (directSourceUrl.isNotEmpty() && !directSourceUrl.contains("youtube") && !directSourceUrl.contains("google")) {
                                    val formatted = if (directSourceUrl.startsWith("//")) "https:$directSourceUrl" else directSourceUrl
                                    extracted.add(formatted)
                                }

                                val content = sObj.optString("source_content")
                                val match = iframeSrcRegex.find(content)
                                if (match != null) {
                                    var src = match.groupValues[1]
                                    if (src.startsWith("//")) src = "https:$src"
                                    if (!src.contains("youtube") && !src.contains("google")) {
                                        extracted.add(src)
                                    }
                                } else if (content.startsWith("http") || content.startsWith("//")) {
                                    val formatted = if (content.startsWith("//")) "https:$content" else content
                                    if (!formatted.contains("youtube") && !formatted.contains("google")) {
                                        extracted.add(formatted)
                                    }
                                } else {
                                    urlRegex.findAll(content).forEach { uMatch ->
                                        val u = uMatch.value
                                        if ((u.contains("m3u8") || u.contains("mp4") || u.contains("vidmoly") || u.contains("pichive"))) {
                                            extracted.add(u)
                                        }
                                    }
                                }

                                for (itemUrl in extracted) {
                                    if (!iframes.contains(itemUrl)) iframes.add(itemUrl)
                                    if (isDub && !dubbingIframes.contains(itemUrl)) dubbingIframes.add(itemUrl)
                                    if (isSub && !subtitleIframes.contains(itemUrl)) subtitleIframes.add(itemUrl)
                                    if (!isDub && !isSub) {
                                        if (!dubbingIframes.contains(itemUrl)) dubbingIframes.add(itemUrl)
                                        if (!subtitleIframes.contains(itemUrl)) subtitleIframes.add(itemUrl)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. DOM iframe'lerini de kontrol et
        doc.select("iframe").forEach { iframe ->
            val src = iframe.attr("src").ifEmpty { iframe.attr("data-src") }
            if (src.isNotEmpty() && !src.contains("youtube") && !src.contains("google")) {
                val formattedSrc = if (src.startsWith("//")) "https:$src" else src
                if (!iframes.contains(formattedSrc)) {
                    iframes.add(formattedSrc)
                    if (!dubbingIframes.contains(formattedSrc)) dubbingIframes.add(formattedSrc)
                    if (!subtitleIframes.contains(formattedSrc)) subtitleIframes.add(formattedSrc)
                }
            }
        }

        // 3. Eğer şifreli veride sezon yoksa fakat DOM'da dizi bölümleri varsa DOM'dan da tespit et
        if (seasonsMap.isEmpty()) {
            val epRegex = Regex("""/([a-zA-Z0-9_\-]+)-(\d+)-sezon-(\d+)-bolum""")
            doc.select("a[href*='-sezon-'][href*='-bolum']").forEach { aTag ->
                val href = aTag.attr("href")
                val match = epRegex.find(href)
                if (match != null) {
                    isSeries = true
                    val sNum = match.groupValues[2].toIntOrNull() ?: 1
                    val epNum = match.groupValues[3].toIntOrNull() ?: 1
                    val epTitle = aTag.text().ifEmpty { "$epNum. Bölüm" }
                    val fullEpUrl = if (href.startsWith("http")) href else if (href.startsWith("/")) "$baseUrl$href" else "$baseUrl/$href"

                    val episodeItems = seasonsMap.getOrPut(sNum) { mutableListOf() }
                    if (episodeItems.none { it.url == fullEpUrl }) {
                        episodeItems.add(Episode(epNum, epTitle, fullEpUrl))
                    }
                }
            }
        }

        val parsedSeasons = seasonsMap.map { (sNum, epList) ->
            Season(seasonNumber = sNum, name = "$sNum. Sezon", episodes = epList)
        }
        if (parsedSeasons.isNotEmpty()) {
            isSeries = true
        }

        val languages = mutableListOf<String>()
        if (dubbingIframes.isNotEmpty()) languages.add("Türkçe Dublaj")
        if (subtitleIframes.isNotEmpty()) languages.add("Türkçe Altyazı")
        if (languages.isEmpty() && iframes.isNotEmpty()) {
            languages.add("Türkçe Dublaj")
            languages.add("Türkçe Altyazı")
        }

        MovieDetail(
            title = title,
            description = description,
            posterUrl = poster,
            iframes = iframes,
            isSeries = isSeries,
            seasons = parsedSeasons,
            provider = name,
            languages = languages,
            dubbingIframes = dubbingIframes,
            subtitleIframes = subtitleIframes,
            hasDub = dubbingIframes.isNotEmpty(),
            hasSubtitle = subtitleIframes.isNotEmpty()
        )
    }

    override suspend fun getEpisodeSources(episodeUrl: String): tv.newtv.data.models.EpisodeSources = withContext(Dispatchers.IO) {
        val doc = fetchDocument(episodeUrl)
        val html = doc.html()
        val iframes = mutableListOf<String>()
        val dubbingIframes = mutableListOf<String>()
        val subtitleIframes = mutableListOf<String>()

        val decrypted = NextJsAesDecryptor.extractAndDecryptFromHtml(html)
        if (decrypted != null) {
            val related = decrypted.optJSONObject("RelatedResults")
            if (related != null) {
                val iframeSrcRegex = Regex("""src\s*=\s*["']([^"']+)["']""")
                val urlRegex = Regex("""https?://[^\s"'<>]+""")

                val keys = related.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (key.contains("Source", ignoreCase = true) || key.contains("Part", ignoreCase = true)) {
                        val partObj = related.optJSONObject(key)
                        val resultArr = partObj?.optJSONArray("result")
                        if (resultArr != null) {
                            for (i in 0 until resultArr.length()) {
                                val sObj = resultArr.optJSONObject(i) ?: continue
                                val langName = sObj.optString("language_name").lowercase()
                                val srcName = sObj.optString("source_name").lowercase()
                                val isDub = langName.contains("dublaj") || srcName.contains("dublaj") || key.contains("dublaj", ignoreCase = true)
                                val isSub = langName.contains("altyaz") || srcName.contains("altyaz") || key.contains("altyaz", ignoreCase = true)

                                val extracted = mutableListOf<String>()
                                val directSourceUrl = sObj.optString("source_url").ifEmpty { sObj.optString("url") }
                                if (directSourceUrl.isNotEmpty() && !directSourceUrl.contains("youtube") && !directSourceUrl.contains("google")) {
                                    val formatted = if (directSourceUrl.startsWith("//")) "https:$directSourceUrl" else directSourceUrl
                                    extracted.add(formatted)
                                }

                                val content = sObj.optString("source_content")
                                val match = iframeSrcRegex.find(content)
                                if (match != null) {
                                    var src = match.groupValues[1]
                                    if (src.startsWith("//")) src = "https:$src"
                                    if (!src.contains("youtube") && !src.contains("google")) {
                                        extracted.add(src)
                                    }
                                } else if (content.startsWith("http") || content.startsWith("//")) {
                                    val formatted = if (content.startsWith("//")) "https:$content" else content
                                    if (!formatted.contains("youtube") && !formatted.contains("google")) {
                                        extracted.add(formatted)
                                    }
                                } else {
                                    urlRegex.findAll(content).forEach { uMatch ->
                                        val u = uMatch.value
                                        if ((u.contains("m3u8") || u.contains("mp4") || u.contains("vidmoly") || u.contains("pichive"))) {
                                            extracted.add(u)
                                        }
                                    }
                                }

                                for (itemUrl in extracted) {
                                    if (!iframes.contains(itemUrl)) iframes.add(itemUrl)
                                    if (isDub && !dubbingIframes.contains(itemUrl)) dubbingIframes.add(itemUrl)
                                    if (isSub && !subtitleIframes.contains(itemUrl)) subtitleIframes.add(itemUrl)
                                    if (!isDub && !isSub) {
                                        if (!dubbingIframes.contains(itemUrl)) dubbingIframes.add(itemUrl)
                                        if (!subtitleIframes.contains(itemUrl)) subtitleIframes.add(itemUrl)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        doc.select("iframe").forEach { iframe ->
            val src = iframe.attr("src").ifEmpty { iframe.attr("data-src") }
            if (src.isNotEmpty() && !src.contains("youtube") && !src.contains("google")) {
                val formattedSrc = if (src.startsWith("//")) "https:$src" else src
                if (!iframes.contains(formattedSrc)) {
                    iframes.add(formattedSrc)
                    if (!dubbingIframes.contains(formattedSrc)) dubbingIframes.add(formattedSrc)
                    if (!subtitleIframes.contains(formattedSrc)) subtitleIframes.add(formattedSrc)
                }
            }
        }

        val all = (dubbingIframes + subtitleIframes).distinct()
        tv.newtv.data.models.EpisodeSources(
            iframes = if (all.isNotEmpty()) all else iframes,
            dubbingIframes = dubbingIframes.ifEmpty { iframes },
            subtitleIframes = subtitleIframes.ifEmpty { iframes },
            hasDub = dubbingIframes.isNotEmpty(),
            hasSubtitle = subtitleIframes.isNotEmpty()
        )
    }

    override suspend fun getEpisodeIframes(episodeUrl: String): List<String> = withContext(Dispatchers.IO) {
        getEpisodeSources(episodeUrl).iframes
    }
}
